import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';

import '../../../services/video_player.dart';
import '../../../widgets/message_bubble.dart';
import '../../ai_teacher/ai_service.dart';
import 'grammar_result_screen.dart';

class FillTheBlankScreen extends StatefulWidget {
  final List<Map<String, dynamic>> questions;
  final int initialCorrect;
  final int totalQuestions;

  // 🔴 NEW: full review list (arrange se aaya, yahan aur add hoga)
  final List<Map<String, dynamic>> reviewList;

  const FillTheBlankScreen({
    super.key,
    required this.questions,
    required this.initialCorrect,
    required this.totalQuestions,
    required this.reviewList,
  });

  @override
  State<FillTheBlankScreen> createState() => _FillTheBlankScreenState();
}

class _FillTheBlankScreenState extends State<FillTheBlankScreen> {
  final FlutterTts flutterTts = FlutterTts();

  int? selectedIndex;
  List<String> options = [];
  String correctAnswer = "";
  String questionText = "";

  int currentIndex = 0;
  late int correctCount;

  static const Color backgroundColor = Colors.black;
  static const Color accentColor = Colors.cyanAccent;
  static const Color glowColor = Color(0xFF80FFFF);
  static const Color textColor = Colors.white;
  static const Color correctOptionColor = Colors.cyanAccent;

  @override
  void initState() {
    super.initState();
    correctCount = widget.initialCorrect;
    _loadQuestion(0);
  }
  String meaning="";

  void _loadQuestion(int index) {
    final q = widget.questions[index];
    questionText = q["question"] ?? "";
    options = List<String>.from(q["wordList"] ?? []);
    correctAnswer = q["answer"] ?? "";
    selectedIndex = null;
          meaning=q['meaning'];


    _speakQuestion();
    setState(() {});
  }

  Future<void> _speakQuestion() async {
    if (questionText.isEmpty) return;
   AIService().readAloud(  questionText.replaceAll("___", "blank"));

    // await flutterTts.setLanguage("en-IN");
    // await flutterTts.setPitch(1.0);
    // await flutterTts.setSpeechRate(0.55);
    // await flutterTts.setVolume(1.0);
    // await flutterTts.speak(
    //   questionText.replaceAll("___", "blank"),
    // );
  }

  @override
  void dispose() {
    flutterTts.stop();
    super.dispose();
  }

  // ✅ Right ya wrong, dono case me next question
  void _checkAnswer() async {
    if (selectedIndex == null) {
      showResultSnackBar(
        context,
        "Please select an answer first!",
        true,
      );
      return;
    }

    final selectedAnswer = options[selectedIndex!];
    final bool isCorrect = selectedAnswer == correctAnswer;

    // 🔴 REVIEW ENTRY ADD (fill)
    widget.reviewList.add({
      "type": "fill",
      "question": questionText,
      "correct": correctAnswer,
      "user": selectedAnswer,
      "isCorrect": isCorrect,
    });

    if (isCorrect) {
      correctCount++;
      await flutterTts.setSpeechRate(0.6);
      await flutterTts.speak("Correct!");
      showResultSnackBar(context, "✅ Correct Answer!", true);
    } else {
      await flutterTts.setSpeechRate(0.6);
      await flutterTts.speak("That’s not correct.");
      showResultSnackBar(
        context,
        "❌ Incorrect! Correct: $correctAnswer",
        false,
      );
    }

    // 👉 Right / wrong dono pe aage badho
    Future.delayed(const Duration(milliseconds: 800), () {
      if (!mounted) return;

      if (currentIndex < widget.questions.length - 1) {
        setState(() {
          currentIndex++;
        });
        _loadQuestion(currentIndex);
      } else {
        // Saare fill-in questions complete → Result screen
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => GrammarResultScreen(
              correct: correctCount,
              total: widget.totalQuestions,
              reviewList: widget.reviewList, // 👈 yahan bhej diya
            ),
          ),
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        Navigator.pushReplacementNamed(context, '/lesson');
        return false;
      },
      child: Scaffold(
         appBar: AppBar(
      leading: IconButton(
        icon: const Icon(Icons.arrow_back),
        onPressed: () {
          Navigator.pushReplacementNamed(context, '/home');
        },
      ),
    ),
        backgroundColor: backgroundColor,
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 20,
              vertical: 30,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text(
                  "Fill in the Blanks",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: accentColor,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 10),

                // 🔸 Progress
                LinearProgressIndicator(
                  value: (currentIndex + 1) /
                      (widget.questions.length.toDouble()),
                  backgroundColor: Colors.white12,
                  color: Colors.orangeAccent,
                  minHeight: 4,
                ),

                const SizedBox(height: 20),

                SizedBox(
                  height: 140,
                  child: TeacherAnimation(),
                ),
                const SizedBox(height: 20),

                Text(
                  questionText,
                  style: const TextStyle(
                    color: textColor,
                    fontSize: 22,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                 Text(
                  meaning,
                  style: const TextStyle(
                    color: textColor,
                    fontSize: 18,
                    fontWeight: FontWeight.w500,
                  ),
                ),

                const SizedBox(height: 40),

                for (int i = 0; i < options.length; i++) ...[
                  _buildOption(i, options[i]),
                  const SizedBox(height: 18),
                ],

                const SizedBox(height: 30),

                ElevatedButton(
                  onPressed: _checkAnswer,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.transparent,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 50,
                      vertical: 16,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                      side: const BorderSide(
                        color: accentColor,
                        width: 1.8,
                      ),
                    ),
                    shadowColor: accentColor.withOpacity(0.6),
                  ),
                  child: const Text(
                    "Continue",
                    style: TextStyle(
                      color: accentColor,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),

                const SizedBox(height: 16),

                TextButton(
                  onPressed: _speakQuestion,
                  child: const Text(
                    "🔁 Listen Again",
                    style: TextStyle(
                      color: accentColor,
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                      decoration: TextDecoration.underline,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildOption(int index, String text) {
    final bool isSelected = selectedIndex == index;

    return GestureDetector(
      onTap: () {
        setState(() {
          selectedIndex = index;
        });
      },
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(
          vertical: 14,
          horizontal: 16,
        ),
        decoration: BoxDecoration(
          color: isSelected
              ? correctOptionColor.withOpacity(0.2)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected ? correctOptionColor : accentColor,
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: glowColor.withOpacity(0.4),
              blurRadius: 8,
              spreadRadius: 1,
            ),
          ],
        ),
        child: Center(
          child: Text(
            text,
            style: TextStyle(
              color: isSelected ? correctOptionColor : textColor,
              fontSize: 18,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
      ),
    );
  }
}
