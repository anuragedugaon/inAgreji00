import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../../config/openai_config.dart';
import 'ai_service.dart';

class DailyGrammarService {
  final String _apiUrl = "https://api.openai.com/v1/chat/completions";

  /// List of models to try (fallback order) — includes your paid gpt-5-nano
  final List<String> _modelFallbacks = [
    "gpt-4o-mini",     // paid, fast, cheap fallback
    "o3-mini",         // strong reasoning fallback
    "gpt-4o",          // high-quality fallback
    "gpt-3.5-turbo",   // legacy fallback
  ];

  /// Helper: try to extract a JSON object substring from `text`.
String? _extractJsonString(String text) {
  final firstOpen = text.indexOf('{');
  if (firstOpen == -1) return null;

  int lastClose = text.lastIndexOf('}');
  if (lastClose == -1) lastClose = text.length - 1;

  String candidate = text.substring(firstOpen, lastClose + 1);

  int opens = 0, closes = 0;
  for (var c in candidate.split('')) {
    if (c == '{') opens++;
    if (c == '}') closes++;
  }

  if (opens > closes) {
    candidate += '}' * (opens - closes);
  }

  return candidate;
}

/// 🔥 Daily lesson + arrange + fill (WITH LearningProgression)
Future<Map<String, dynamic>> getDailyLessonWithQuestions({
  String? extraContext,
}) async {
  final prefs = await SharedPreferences.getInstance();

  final selectedLangCode =
      prefs.getString('selected_language_code')?.toLowerCase() ?? 'en';
  final selectedLangName =
      prefs.getString('selected_language') ?? 'English';
  final userLevel = prefs.getString('selected_level') ?? 'beginner';

  // 🔥 GLOBAL LEARNING PROGRESSION
  final progress = await LearningProgression.today();

  debugPrint(
      "📘 Daily Lesson | Day ${progress.day} | Stage ${progress.stage} | Level $userLevel");

  final systemPrompt =
      "You are an English tutor AI for $userLevel level students. "
      "Learning day ${progress.day}, difficulty stage ${progress.stage}. "
      "${progress.difficultyHint} "
      "The app interface can be $selectedLangName ($selectedLangCode), "
      "but you MUST always respond only in English. "
      "Return ONLY raw JSON. No markdown. No commentary.";

  final int arrangeCount = progress.stage <= 1 ? 6 : progress.stage == 2 ? 8 : 10;
  final int fillCount = progress.stage <= 1 ? 6 : progress.stage == 2 ? 8 : 10;

  String userPrompt = """
Create an English grammar practice session for a $userLevel learner.

LEARNING STAGE:
- Day ${progress.day}
- Difficulty stage ${progress.stage}

LESSON:
- ONE very short grammar lesson
- Very simple English
- Maximum 3–4 lines

ARRANGE QUESTIONS:
- Create EXACTLY $arrangeCount sentence-arrangement questions
- Very short, simple sentences
- Meanings MUST be in app language: $selectedLangName ($selectedLangCode)


FILL-IN-THE-BLANK:
- Create EXACTLY $fillCount fill-in-the-blank questions
- Use ONE blank only: ___
- Meanings MUST be in app language: $selectedLangName ($selectedLangCode)


FORMAT (STRICT JSON ONLY):
{
  "lesson": "string",
  "arrange_questions": [
    {
      "sentence": "string",
      "meaning": "string ",

      "words": ["..."],
      "answer": ["..."],
      "explanation": "string"
    }
  ],
  "fill_questions": [
    {
      "question": "string ___",
        "meaning": "string ___",

      "wordList": ["a","b","c"],
      "answer": "string"
    }
  ]
}

RULES:
- All text MUST be in English.
- Keep everything VERY SIMPLE for this stage.
- Do NOT add extra top-level keys.
- Do NOT include markdown or explanations outside JSON.
""";

  if (extraContext != null && extraContext.isNotEmpty) {
    userPrompt += "\nAdditional student context: $extraContext";
  }

  for (final modelName in _modelFallbacks) {
    try {
      debugPrint("➡️ Trying model: $modelName");

      final body = {
        "model": modelName,
        "messages": [
          {"role": "system", "content": systemPrompt},
          {"role": "user", "content": userPrompt}
        ],
        "max_tokens": 2000,
        "temperature": 0.15,
      };

      final res = await http.post(
        Uri.parse(_apiUrl),
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer ${OpenAIConfig.apiKey}",
        },
        body: jsonEncode(body),
      );

      if (res.statusCode != 200) {
        debugPrint("⚠️ [$modelName] HTTP ${res.statusCode}");
        continue;
      }

      final decoded = jsonDecode(res.body);
      final choice = decoded['choices']?[0];
      String? aiText = choice?['message']?['content'];

      if (aiText == null || aiText.trim().isEmpty) continue;

      aiText = aiText.replaceAll("```json", "").replaceAll("```", "").trim();

      final extracted = _extractJsonString(aiText);
      if (extracted == null) continue;

      Map<String, dynamic> parsed;
      try {
        parsed = jsonDecode(extracted);
      } catch (_) {
        final repaired = extracted
            .replaceAll(RegExp(r',\s*}'), '}')
            .replaceAll(RegExp(r',\s*]'), ']');
        parsed = jsonDecode(repaired);
      }

      if (!parsed.containsKey('lesson') ||
          !parsed.containsKey('arrange_questions') ||
          !parsed.containsKey('fill_questions')) {
        continue;
      }

      debugPrint(
          "✅ Daily lesson ready (Stage ${progress.stage})");
      return parsed;
    } catch (e) {
      debugPrint("❌ Error ($modelName): $e");
    }
  }

  return {
    "error": "All models failed to generate daily lesson"
  };
}



}