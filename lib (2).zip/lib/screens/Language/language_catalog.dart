import 'package:flutter/foundation.dart';

@immutable
class LanguageInfo {
  final String code;        // e.g. en, hi, bn, hi-Latn
  final String englishName; // English name
  final String nativeName;  // Name in its own script

  const LanguageInfo({
    required this.code,
    required this.englishName,
    required this.nativeName,
  });
}

/// These are the languages where you currently have l10n json files
/// (en.json, hi.json, bn.json). We use these when calling
/// appProvider.changeLanguage so UI text doesn't break.
const Set<String> kUiSupportedLanguageCodes = <String>{
  'en', // English
  'hi', // Hindi
  'bn', // Bengali
  'ta', // Tamil
  'te', // Telugu
  'kn', // Kannada
  'ml', // Malayalam
  'mr', // Marathi
  'gu', // Gujarati
  'pa', // Punjabi
  'or', // Odia
  'as', // Assamese
  'ur', // Urdu
};


/// World-wide language catalog used on ChooseLanguageScreen.
/// Add/remove entries here only – screen will auto-update.
const List<LanguageInfo> kWorldLanguages = <LanguageInfo>[
  // 🔹 Core app languages
  LanguageInfo(code: 'en', englishName: 'English', nativeName: 'English'),
  LanguageInfo(code: 'hi', englishName: 'Hindi', nativeName: 'हिन्दी'),
  LanguageInfo(code: 'bn', englishName: 'Bengali', nativeName: 'বাংলা'),
  LanguageInfo(code: 'hi-Latn', englishName: 'Hinglish', nativeName: 'Hinglish'),

  // 🔹 Major world languages
  LanguageInfo(code: 'es', englishName: 'Spanish', nativeName: 'Español'),
  LanguageInfo(code: 'fr', englishName: 'French', nativeName: 'Français'),
  LanguageInfo(code: 'de', englishName: 'German', nativeName: 'Deutsch'),
  LanguageInfo(code: 'ru', englishName: 'Russian', nativeName: 'Русский'),
  LanguageInfo(code: 'pt', englishName: 'Portuguese', nativeName: 'Português'),
  LanguageInfo(code: 'pt-BR', englishName: 'Portuguese (Brazil)', nativeName: 'Português (Brasil)'),
  LanguageInfo(code: 'ar', englishName: 'Arabic', nativeName: 'العربية'),
  LanguageInfo(code: 'zh-CN', englishName: 'Chinese (Simplified)', nativeName: '简体中文'),
  LanguageInfo(code: 'zh-TW', englishName: 'Chinese (Traditional)', nativeName: '繁體中文'),
  LanguageInfo(code: 'ja', englishName: 'Japanese', nativeName: '日本語'),
  LanguageInfo(code: 'ko', englishName: 'Korean', nativeName: '한국어'),
  LanguageInfo(code: 'it', englishName: 'Italian', nativeName: 'Italiano'),
  LanguageInfo(code: 'tr', englishName: 'Turkish', nativeName: 'Türkçe'),

  // 🔹 Indian languages
  LanguageInfo(code: 'ta', englishName: 'Tamil', nativeName: 'தமிழ்'),
  LanguageInfo(code: 'te', englishName: 'Telugu', nativeName: 'తెలుగు'),
  LanguageInfo(code: 'mr', englishName: 'Marathi', nativeName: 'मराठी'),
  LanguageInfo(code: 'gu', englishName: 'Gujarati', nativeName: 'ગુજરાતી'),
  LanguageInfo(code: 'kn', englishName: 'Kannada', nativeName: 'ಕನ್ನಡ'),
  LanguageInfo(code: 'ml', englishName: 'Malayalam', nativeName: 'മലയാളം'),
  LanguageInfo(code: 'pa', englishName: 'Punjabi', nativeName: 'ਪੰਜਾਬੀ'),
  LanguageInfo(code: 'ur', englishName: 'Urdu', nativeName: 'اردو'),
  LanguageInfo(code: 'or', englishName: 'Odia', nativeName: 'ଓଡ଼ିଆ'),
  LanguageInfo(code: 'as', englishName: 'Assamese', nativeName: 'অসমীয়া'),
  LanguageInfo(code: 'ne', englishName: 'Nepali', nativeName: 'नेपाली'),
  LanguageInfo(code: 'si', englishName: 'Sinhala', nativeName: 'සිංහල'),
  LanguageInfo(code: 'sa', englishName: 'Sanskrit', nativeName: 'संस्कृतम्'),

  // 🔹 Europe
  LanguageInfo(code: 'pl', englishName: 'Polish', nativeName: 'Polski'),
  LanguageInfo(code: 'uk', englishName: 'Ukrainian', nativeName: 'Українська'),
  LanguageInfo(code: 'nl', englishName: 'Dutch', nativeName: 'Nederlands'),
  LanguageInfo(code: 'sv', englishName: 'Swedish', nativeName: 'Svenska'),
  LanguageInfo(code: 'no', englishName: 'Norwegian', nativeName: 'Norsk'),
  LanguageInfo(code: 'da', englishName: 'Danish', nativeName: 'Dansk'),
  LanguageInfo(code: 'fi', englishName: 'Finnish', nativeName: 'Suomi'),
  LanguageInfo(code: 'cs', englishName: 'Czech', nativeName: 'Čeština'),
  LanguageInfo(code: 'sk', englishName: 'Slovak', nativeName: 'Slovenčina'),
  LanguageInfo(code: 'ro', englishName: 'Romanian', nativeName: 'Română'),
  LanguageInfo(code: 'hu', englishName: 'Hungarian', nativeName: 'Magyar'),
  LanguageInfo(code: 'bg', englishName: 'Bulgarian', nativeName: 'Български'),
  LanguageInfo(code: 'el', englishName: 'Greek', nativeName: 'Ελληνικά'),
  LanguageInfo(code: 'sr', englishName: 'Serbian', nativeName: 'Српски'),
  LanguageInfo(code: 'hr', englishName: 'Croatian', nativeName: 'Hrvatski'),
  LanguageInfo(code: 'sl', englishName: 'Slovene', nativeName: 'Slovenščina'),
  LanguageInfo(code: 'et', englishName: 'Estonian', nativeName: 'Eesti'),
  LanguageInfo(code: 'lv', englishName: 'Latvian', nativeName: 'Latviešu'),
  LanguageInfo(code: 'lt', englishName: 'Lithuanian', nativeName: 'Lietuvių'),
  LanguageInfo(code: 'sq', englishName: 'Albanian', nativeName: 'Shqip'),
  LanguageInfo(code: 'ga', englishName: 'Irish', nativeName: 'Gaeilge'),
  LanguageInfo(code: 'cy', englishName: 'Welsh', nativeName: 'Cymraeg'),
  LanguageInfo(code: 'eu', englishName: 'Basque', nativeName: 'Euskara'),
  LanguageInfo(code: 'gl', englishName: 'Galician', nativeName: 'Galego'),

  // 🔹 Central & East Asia
  LanguageInfo(code: 'kk', englishName: 'Kazakh', nativeName: 'Қазақ тілі'),
  LanguageInfo(code: 'uz', englishName: 'Uzbek', nativeName: 'Oʻzbekcha'),
  LanguageInfo(code: 'mn', englishName: 'Mongolian', nativeName: 'Монгол'),
  LanguageInfo(code: 'lo', englishName: 'Lao', nativeName: 'ລາວ'),
  LanguageInfo(code: 'km', englishName: 'Khmer', nativeName: 'ខ្មែរ'),
  LanguageInfo(code: 'my', englishName: 'Burmese', nativeName: 'မြန်မာ'),

  // 🔹 South-East Asia
  LanguageInfo(code: 'id', englishName: 'Indonesian', nativeName: 'Bahasa Indonesia'),
  LanguageInfo(code: 'ms', englishName: 'Malay', nativeName: 'Bahasa Melayu'),
  LanguageInfo(code: 'vi', englishName: 'Vietnamese', nativeName: 'Tiếng Việt'),
  LanguageInfo(code: 'th', englishName: 'Thai', nativeName: 'ไทย'),
  LanguageInfo(code: 'tl', englishName: 'Tagalog', nativeName: 'Tagalog'),

  // 🔹 Middle-East & Africa
  LanguageInfo(code: 'fa', englishName: 'Persian', nativeName: 'فارسی'),
  LanguageInfo(code: 'he', englishName: 'Hebrew', nativeName: 'עברית'),
  LanguageInfo(code: 'am', englishName: 'Amharic', nativeName: 'አማርኛ'),
  LanguageInfo(code: 'sw', englishName: 'Swahili', nativeName: 'Kiswahili'),
  LanguageInfo(code: 'yo', englishName: 'Yoruba', nativeName: 'Yorùbá'),
  LanguageInfo(code: 'ig', englishName: 'Igbo', nativeName: 'Asụsụ Igbo'),
  LanguageInfo(code: 'ha', englishName: 'Hausa', nativeName: 'Hausa'),
  LanguageInfo(code: 'zu', englishName: 'Zulu', nativeName: 'isiZulu'),
  LanguageInfo(code: 'xh', englishName: 'Xhosa', nativeName: 'isiXhosa'),

  // 🔹 Others (you can keep adding)
  LanguageInfo(code: 'af', englishName: 'Afrikaans', nativeName: 'Afrikaans'),
];
