// import 'package:flutter/material.dart';
// import 'package:flutter_tts/flutter_tts.dart';

// class ListenSelectScreen extends StatefulWidget {
//   const ListenSelectScreen({super.key});

//   @override
//   State<ListenSelectScreen> createState() => _ListenSelectScreenState();
// }

// class _ListenSelectScreenState extends State<ListenSelectScreen>
//     with TickerProviderStateMixin {
//   final FlutterTts tts = FlutterTts();

//   // 🎨 THEME COLORS
//   static const Color backgroundColor = Colors.black;
//   static const Color accentColor = Colors.cyanAccent;
//   static const Color glowColor = Color(0xFF80FFFF);
//   static const Color textColor = Colors.white;

//   bool loading = true;
//   late String word;
//   late String correct;
//   List<Map<String, dynamic>> options = [];

//   late AnimationController screenController;
//   late AnimationController speakerController;
//   late AnimationController optionController;
//   late AnimationController resultController;

//   late Animation<double> fadeAnim;
//   late Animation<Offset> slideAnim;
//   late Animation<double> speakerPulse;
//   late Animation<double> optionScale;
//   late Animation<double> resultScale;
//   late Animation<Offset> shakeAnim;

//   @override
//   void initState() {
//     super.initState();

//     screenController =
//         AnimationController(vsync: this, duration: const Duration(milliseconds: 700));
//     speakerController =
//         AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
//     optionController =
//         AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
//     resultController =
//         AnimationController(vsync: this, duration: const Duration(milliseconds: 500));

//     fadeAnim = CurvedAnimation(parent: screenController, curve: Curves.easeIn);
//     slideAnim = Tween(begin: const Offset(0, 0.2), end: Offset.zero)
//         .animate(CurvedAnimation(parent: screenController, curve: Curves.easeOut));

//     speakerPulse =
//         Tween(begin: 1.0, end: 1.15).animate(CurvedAnimation(
//       parent: speakerController,
//       curve: Curves.easeInOut,
//     ));

//     optionScale =
//         CurvedAnimation(parent: optionController, curve: Curves.elasticOut);
//     resultScale =
//         CurvedAnimation(parent: resultController, curve: Curves.elasticOut);

//     shakeAnim = Tween(begin: Offset.zero, end: const Offset(0.04, 0))
//         .animate(CurvedAnimation(parent: resultController, curve: Curves.elasticIn));

//     screenController.forward();
//     loadQuestion();
//   }

//   // 🔹 MOCK DATA (API se replace kar sakte ho)
//   Future<void> loadQuestion() async {
//     await Future.delayed(const Duration(milliseconds: 600));
//     setState(() {
//       word = "Apple";
//       correct = "Apple";
//       options = [
//         {
//           "label": "Apple",
//           "image":
//               "https://upload.wikimedia.org/wikipedia/commons/1/15/Red_Apple.jpg"
//         },
//         {"label": "Banana", "image": ""}
//       ];
//       loading = false;
//     });
//     optionController.forward(from: 0);
//   }

//   void speak() async {
//     speakerController.repeat(reverse: true);
//     await tts.speak(word);
//     speakerController.stop();
//     speakerController.reset();
//   }

//   void select(String label) {
//     final bool isCorrect = label == correct;
//     resultController.forward(from: 0);

//     showModalBottomSheet(
//       context: context,
//       backgroundColor: Colors.transparent,
//       isDismissible: false,
//       builder: (_) {
//         return ScaleTransition(
//           scale: resultScale,
//           child: Container(
//             height: MediaQuery.of(context).size.height * 0.55, // 🔥 FULL HEIGHT
//             width: double.infinity,
//             padding: const EdgeInsets.all(24),
//             decoration: BoxDecoration(
//               borderRadius: const BorderRadius.vertical(
//                 top: Radius.circular(30),
//               ),
//               gradient: LinearGradient(
//                 colors: isCorrect
//                     ? [Colors.green.shade600, Colors.green.shade900]
//                     : [Colors.red.shade600, Colors.red.shade900],
//               ),
//               boxShadow: [
//                 BoxShadow(
//                   color: glowColor.withOpacity(0.5),
//                   blurRadius: 40,
//                 )
//               ],
//             ),
//             child: Column(
//               children: [
//                 Icon(
//                   isCorrect ? Icons.verified : Icons.error,
//                   size: 70,
//                   color: Colors.white,
//                 ),
//                 const SizedBox(height: 14),
//                 Text(
//                   isCorrect ? "Excellent!" : "Try Again!",
//                   style: const TextStyle(
//                     color: textColor,
//                     fontSize: 26,
//                     fontWeight: FontWeight.bold,
//                   ),
//                 ),
//                 const SizedBox(height: 10),
//                 Text(
//                   "\"$word\"",
//                   style: const TextStyle(
//                     color: textColor,
//                     fontSize: 18,
//                   ),
//                 ),
//                 const Spacer(),

//                 // ✅ FULL WIDTH + PROPER HEIGHT BUTTON
//                 SizedBox(
//                   width: double.infinity,
//                   height: 52,
//                   child: ElevatedButton(
//                     onPressed: () {
//                       Navigator.pop(context);
//                       setState(() => loading = true);
//                       loadQuestion();
//                     },
//                     style: ElevatedButton.styleFrom(
//                       backgroundColor: accentColor,
//                       padding: EdgeInsets.zero,
//                       shape: RoundedRectangleBorder(
//                         borderRadius: BorderRadius.circular(14),
//                       ),
//                       elevation: 6,
//                       shadowColor: accentColor.withOpacity(0.6),
//                     ),
//                     child: const Text(
//                       "Next ▶",
//                       style: TextStyle(
//                         color: Colors.black,
//                         fontSize: 16,
//                         fontWeight: FontWeight.bold,
//                       ),
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         );
//       },
//     );
//   }

//   Widget safeImage(String? url) {
//     if (url == null || url.isEmpty) {
//       return const Icon(Icons.image_not_supported,
//           color: Colors.white24, size: 80);
//     }
//     return Image.network(
//       url,
//       height: 100,
//       fit: BoxFit.contain,
//       errorBuilder: (_, __, ___) =>
//           const Icon(Icons.broken_image, color: Colors.white24, size: 80),
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     if (loading) {
//       return const Scaffold(
//         backgroundColor: backgroundColor,
//         body: Center(child: CircularProgressIndicator(color: accentColor)),
//       );
//     }

//     return Scaffold(
//       backgroundColor: backgroundColor,
//       body: Container(
//         decoration: const BoxDecoration(
//           gradient: RadialGradient(
//             center: Alignment.topCenter,
//             radius: 1.2,
//             colors: [Color(0xFF002222), Colors.black],
//           ),
//         ),
//         child: SafeArea(
//           child: FadeTransition(
//             opacity: fadeAnim,
//             child: SlideTransition(
//               position: slideAnim,
//               child: Column(
//                 children: [
//                   const SizedBox(height: 12),

//                   const Text(
//                     "Listen & Choose",
//                     style: TextStyle(
//                       color: textColor,
//                       fontSize: 26,
//                       fontWeight: FontWeight.bold,
//                     ),
//                   ),

//                   const SizedBox(height: 16),

//                   // 🔊 CENTER SPEAKER
//                   Expanded(
//                     flex: 3,
//                     child: Center(
//                       child: ScaleTransition(
//                         scale: speakerPulse,
//                         child: GestureDetector(
//                           onTap: speak,
//                           child: Container(
//                             height: 110,
//                             width: 110,
//                             decoration: BoxDecoration(
//                               shape: BoxShape.circle,
//                               color: accentColor,
//                               boxShadow: [
//                                 BoxShadow(
//                                   color: glowColor.withOpacity(0.9),
//                                   blurRadius: 45,
//                                   spreadRadius: 4,
//                                 )
//                               ],
//                             ),
//                             child: const Icon(
//                               Icons.volume_up,
//                               color: Colors.black,
//                               size: 48,
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),

//                   // 🎴 OPTIONS PANEL
//                   Expanded(
//                     flex: 4,
//                     child: ScaleTransition(
//                       scale: optionScale,
//                       child: Container(
//                         padding: const EdgeInsets.all(16),
//                         decoration: BoxDecoration(
//                           color: Colors.black.withOpacity(0.55),
//                           borderRadius: const BorderRadius.vertical(
//                             top: Radius.circular(28),
//                           ),
//                           boxShadow: [
//                             BoxShadow(
//                               color: glowColor.withOpacity(0.25),
//                               blurRadius: 30,
//                             )
//                           ],
//                         ),
//                         child: Row(
//                           children: options.map((o) {
//                             return Expanded(
//                               child: GestureDetector(
//                                 onTap: () => select(o["label"]),
//                                 child: SlideTransition(
//                                   position: shakeAnim,
//                                   child: Container(
//                                     margin:
//                                         const EdgeInsets.symmetric(horizontal: 8),
//                                     padding: const EdgeInsets.all(14),
//                                     decoration: BoxDecoration(
//                                       borderRadius: BorderRadius.circular(22),
//                                       color: Colors.white.withOpacity(0.06),
//                                       border: Border.all(
//                                         color: accentColor.withOpacity(0.6),
//                                       ),
//                                       boxShadow: [
//                                         BoxShadow(
//                                           color: glowColor.withOpacity(0.25),
//                                           blurRadius: 25,
//                                         )
//                                       ],
//                                     ),
//                                     child: Column(
//                                       mainAxisAlignment:
//                                           MainAxisAlignment.center,
//                                       children: [
//                                         safeImage(o["image"]),
//                                         const SizedBox(height: 12),
//                                         Text(
//                                           o["label"],
//                                           style: const TextStyle(
//                                             color: textColor,
//                                             fontSize: 16,
//                                             fontWeight: FontWeight.w600,
//                                           ),
//                                         )
//                                       ],
//                                     ),
//                                   ),
//                                 ),
//                               ),
//                             );
//                           }).toList(),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         ),
//       ),
//     );
//   }

//   @override
//   void dispose() {
//     screenController.dispose();
//     speakerController.dispose();
//     optionController.dispose();
//     resultController.dispose();
//     super.dispose();
//   }
// }





import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import '../../main.dart';
import '../ai_teacher/ai_service.dart';
import 'WordMeaningScreen.dart';
import 'openai_service.dart';

// 🔥 ADD ON (RouteObserver import)

class ListenSelectScreen extends StatefulWidget {
  const ListenSelectScreen({super.key});

  @override
  State<ListenSelectScreen> createState() => _ListenSelectScreenState();
}

class _ListenSelectScreenState extends State<ListenSelectScreen>
    with TickerProviderStateMixin, RouteAware {
  final FlutterTts tts = FlutterTts();
  final OpenAIService _ai = OpenAIService();
  final AIService _aiService = AIService();

  // 🎨 THEME
  static const Color backgroundColor = Colors.black;
  static const Color accentColor = Colors.cyanAccent;
  static const Color glowColor = Color(0xFF80FFFF);
  static const Color textColor = Colors.white;

  int correctCount = 0;
  bool loading = true;

  List<Map<String, dynamic>> questions = [];
  int currentIndex = 0;

    /// 🛑 Stop speaking immediately

  late AnimationController speakerController;
  late AnimationController optionController;
  late Animation<double> speakerPulse;
  late Animation<double> optionScale;

  // 🔥 ADD ON (state + tts guards)
  String? _lastSpokenWord;
  bool _isSpeaking = false;
  bool _autoSpokenOnce = false;

  @override
  void initState() {
    super.initState();

    speakerController =
        AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    optionController =
        AnimationController(vsync: this, duration: const Duration(milliseconds: 600));

    speakerPulse = Tween(begin: 1.0, end: 1.15).animate(
      CurvedAnimation(parent: speakerController, curve: Curves.easeInOut),
    );
    optionScale =
        CurvedAnimation(parent: optionController, curve: Curves.elasticOut);

    tts.setLanguage("en-IN");
    tts.setSpeechRate(0.45);

    loadQuestions();
  }

  // 🔥 ADD ON (Route subscribe)
  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    routeObserver.subscribe(this, ModalRoute.of(context)! as PageRoute);
  }

  // 🔥 ADD ON (BACK detect)
  @override
  void didPopNext() {
    _autoSpokenOnce = false;
    _lastSpokenWord = null;

    WidgetsBinding.instance.addPostFrameCallback((_) {
      speak();
    });
  }

  // ================= AI =================
  Future<void> loadQuestions() async {
    try {
      setState(() => loading = true);

      final data = await _ai.getListenSelectQuestions();

      setState(() {
        questions = data;
        currentIndex = 0;
        correctCount = 0;
        loading = false;
        _autoSpokenOnce = false;
        _lastSpokenWord = null;
      });

      optionController.forward(from: 0);
    } catch (e) {
      debugPrint("❌ Load error: $e");
      setState(() => loading = false);
    }
  }

  // 🔊 SPEAK (SAFE)
  Future<void> speak() async {
    if (questions.isEmpty) return;

    final word = questions[currentIndex]["correct"]["word"];

    if (_lastSpokenWord == word) return;
    if (_isSpeaking) return;

    _isSpeaking = true;
    _lastSpokenWord = word;

    await _aiService.speakText(word);

    _isSpeaking = false;
  }

  // ✅ SELECT OPTION
  void selectOption(Map<String, dynamic> option) {
    final correctWord = questions[currentIndex]["correct"]["word"];
    final bool isCorrect = option["word"] == correctWord;
    if (isCorrect) correctCount++;

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isDismissible: false,
      builder: (_) {
        return Container(
          height: MediaQuery.of(context).size.height * 0.32,
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            borderRadius:
                const BorderRadius.vertical(top: Radius.circular(30)),
            gradient: LinearGradient(
              colors: isCorrect
                  ? [Colors.green, Colors.green.shade900]
                  : [Colors.red, Colors.red.shade900],
            ),
          ),
          child: Column(
            children: [
              Icon(
                isCorrect ? Icons.verified : Icons.error,
                size: 64,
                color: Colors.white,
              ),
              const SizedBox(height: 12),
              Text(
                isCorrect ? "Correct!" : "Wrong!",
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.bold),
              ),
              const Spacer(),
              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton(
                  onPressed: () async{
                    Navigator.pop(context);

                    if (currentIndex < questions.length - 1) {
                      setState(() {
                        currentIndex++;
                        _autoSpokenOnce = false;
                        _lastSpokenWord = null;
                      });

                      optionController.forward(from: 0);

                      var images=await _ai.getImageForWord(option["word"]);

                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => WordMeaningScreen(
                            word: option["word"],
                            type: option["type"],
                            meaning: option["meaning"],
                            image:images??"",
                            correct: correctCount,
                            total: questions.length,
                          ),
                        ),
                      );
                    } else {
                                            var images=await _ai.getImageForWord(option["word"]);

                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => WordMeaningScreen(
                            word: option["word"],
                            type: option["type"],
                            meaning: option["meaning"],
                            image: images??"",
                            correct: correctCount,
                            total: questions.length,
                          ),
                        ),
                      );

                      loadQuestions();
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: accentColor,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14)),
                  ),
                  child: const Text(
                    "Next ▶",
                    style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

Widget premiumImage(String url) {
  return ClipRRect(
    borderRadius: BorderRadius.circular(20),
    child: Stack(
      children: [
        Image.network(
          url,
          height: 150,
          width: double.infinity,
          fit: BoxFit.cover,
        ),
        Container(
          height: 110,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Colors.transparent,
                Colors.black.withOpacity(0.35),
              ],
            ),
          ),
        ),
      ],
    ),
  );
}


  Widget optionCard(Map<String, dynamic> data) {



    return Expanded(
      child: GestureDetector(
        onTap: () => selectOption(data),
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 8),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: accentColor.withOpacity(0.5)),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
             
    FutureBuilder<String?>(
  future: _ai.getImageForWord(data["word"]),
  builder: (context, snapshot) {
    if (snapshot.connectionState == ConnectionState.waiting) {
      return const SizedBox(
        height: 100,
        child: Center(
          child: CircularProgressIndicator(strokeWidth: 2),
        ),
      );
    }

    if (!snapshot.hasData || snapshot.data == null) {
      return const Icon(
        Icons.image,
        color: Colors.white24,
        size: 60,
      );
    }

    return premiumImage(
      snapshot.data!,
    
      
    );
  },
),


              const SizedBox(height: 20),
              Text(
                data["word"].toUpperCase(),
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                  fontWeight: FontWeight.w700,
                  shadows: [
                    Shadow(
                      color: Colors.cyanAccent.withOpacity(0.6),
                      blurRadius: 12,
                    ),
                  ],
                ),
                
              ),
               Text(
                data["local_word"],
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                  shadows: [
                    Shadow(
                      color: Colors.cyanAccent.withOpacity(0.6),
                      blurRadius: 12,
                    ),
                  ],
                )),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(
        backgroundColor: backgroundColor,
        body: Center(
          child: CircularProgressIndicator(color: accentColor),
        ),
      );
    }

    // 🔥 ADD ON (auto speak once per state)
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_autoSpokenOnce) {
        _autoSpokenOnce = true;
        speak();
      }
    });

    final current = questions[currentIndex];

    return WillPopScope(
      onWillPop: () async {
        Navigator.pushReplacementNamed(context, '/home');
         await tts.stop();
        return true;
      },
      child: Scaffold(
        backgroundColor: backgroundColor,
        appBar: AppBar(
      leading: IconButton(
        icon: const Icon(Icons.arrow_back),
        onPressed: () {
          Navigator.pushReplacementNamed(context, '/home');
        },
      ),
    ),
        body: SafeArea(
          child: Column(
            children: [
              const SizedBox(height: 16),
              const Text(
                "Listen & Choose",
                style: TextStyle(
                  color: textColor,
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 20),
      
              Expanded(
                flex: 3,
                child: Center(
                  child: GestureDetector(
                    onTap: () {
                      _lastSpokenWord = null;
                      speak();
                    },
                    child: Container(
                      height: 110,
                      width: 110,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: accentColor,
                        boxShadow: [
                          BoxShadow(color: glowColor, blurRadius: 45),
                        ],
                      ),
                      child: const Icon(
                        Icons.volume_up,
                        size: 48,
                        color: Colors.black,
                      ),
                    ),
                  ),
                ),
              ),
      
              Expanded(
                flex: 2,
                child: Row(
                  children: [
                    optionCard(current["correct"]),
                    optionCard(current["wrong"]),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    routeObserver.unsubscribe(this);
    speakerController.dispose();
    optionController.dispose();
    _aiService.stop();
    super.dispose();
  }
}




// import 'dart:io';
// import 'package:flutter/material.dart';
// import 'package:flutter_tts/flutter_tts.dart';
// import 'package:inangreji_flutter/screens/dailyLessonScreen/CongratulationScreen.dart' ;
// import '../ai_teacher/ai_service.dart';
// import 'WordMeaningScreen.dart';
// import 'openai_service.dart';

// import 'dart:io';
// import 'package:flutter/material.dart';
// import 'package:flutter_tts/flutter_tts.dart';
// import 'openai_service.dart';

// class ListenSelectScreen extends StatefulWidget {
//   const ListenSelectScreen({super.key});

//   @override
//   State<ListenSelectScreen> createState() => _ListenSelectScreenState();
// }

// class _ListenSelectScreenState extends State<ListenSelectScreen>
//     with TickerProviderStateMixin {
//   final FlutterTts tts = FlutterTts();
//   final OpenAIService _ai = OpenAIService();
  
//   final AIService _aiService = AIService(); // ✅ Instance for TTS

//   // 🎨 THEME
//   static const Color backgroundColor = Colors.black;
//   static const Color accentColor = Colors.cyanAccent;
//   static const Color glowColor = Color(0xFF80FFFF);
//   static const Color textColor = Colors.white;
// int correctCount = 0; // ✅ score tracker

//   bool loading = true;

//   // 🔥 QUESTIONS
//   List<Map<String, dynamic>> questions = [];
//   int currentIndex = 0;

//   late AnimationController speakerController;
//   late AnimationController optionController;

//   late Animation<double> speakerPulse;
//   late Animation<double> optionScale;

//   @override
//   void initState() {
//     super.initState();

//     speakerController =
//         AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
//     optionController =
//         AnimationController(vsync: this, duration: const Duration(milliseconds: 600));

//     speakerPulse = Tween(begin: 1.0, end: 1.15).animate(
//       CurvedAnimation(parent: speakerController, curve: Curves.easeInOut),
//     );
//     optionScale =
//         CurvedAnimation(parent: optionController, curve: Curves.elasticOut);

//     tts.setLanguage("en-IN");
//     tts.setSpeechRate(0.45);

//     loadQuestions();
//   }

//   // ================= AI =================
//   Future<void> loadQuestions() async {
//     try {
//       setState(() => loading = true);

//       final data = await _ai.getListenSelectQuestions();

//       setState(() {
//         questions = data;
//         currentIndex = 0;
//         loading = false;
//       });

//       optionController.forward(from: 0);
//   speak(); // 🔊 auto read first correct word

//     } catch (e) {
//       debugPrint("❌ Load error: $e");
//       setState(() => loading = false);
//     }
//   }

//   // 🔊 SPEAK CURRENT WORD
//   // void speak() async {
//   //   final current = questions[currentIndex]["correct"]["word"];
//   //   // speakerController.repeat(reverse: true);
//   //   // await tts.speak(current);
//   //   // speakerController.stop();
//   //   // speakerController.reset();
//   //   _aiService.speakText(current);
//   // }
//   String? _lastSpokenWord;
// bool _isSpeaking = false;

// Future<void> speak() async {
//   if (questions.isEmpty) return;

//   final word = questions[currentIndex]["correct"]["word"];

//   // ❌ same word → no repeat
//   if (_lastSpokenWord == word) return;

//   // ❌ already speaking
//   if (_isSpeaking) return;

//   _isSpeaking = true;
//   _lastSpokenWord = word;

//   await _aiService.speakText(word);

//   _isSpeaking = false;
// }

//   // ✅ SELECT OPTION
//   void selectOption(Map<String, dynamic> option) {
//     final correctWord = questions[currentIndex]["correct"]["word"];
//     final bool isCorrect = option["word"] == correctWord;
//     if (isCorrect) {
//       correctCount++; // ✅ Increment score
//     }

//     showModalBottomSheet(
//       context: context,
//       backgroundColor: Colors.transparent,
//       isDismissible: false,
//       builder: (_) {
//         return Container(
//           height: MediaQuery.of(context).size.height * 0.32,
//           padding: const EdgeInsets.all(24),
//           decoration: BoxDecoration(
//             borderRadius:
//                 const BorderRadius.vertical(top: Radius.circular(30)),
//             gradient: LinearGradient(
//               colors: isCorrect
//                   ? [Colors.green, Colors.green.shade900]
//                   : [Colors.red, Colors.red.shade900],
//             ),
//           ),
//           child: Column(
//             children: [
//               Icon(
//                 isCorrect ? Icons.verified : Icons.error,
//                 size: 64,
//                 color: Colors.white,
//               ),
//               const SizedBox(height: 12),
//               Text(
//                 isCorrect ? "Correct!" : "Wrong!",
//                 style: const TextStyle(
//                   color: Colors.white,
//                   fontSize: 24,
//                   fontWeight: FontWeight.bold,
//                 ),
//               ),
//               const Spacer(),
//               SizedBox(
//                 width: double.infinity,
//                 height: 52,
//                 child: ElevatedButton(
//                   onPressed: () {
//                     Navigator.pop(context);

//                   //  if (isCorrect) {
  
// // }

//                     if (currentIndex < questions.length - 1) {
//                       setState(() {
//                         currentIndex++;
//                       });
//                       optionController.forward(from: 0);
                      
//                       Navigator.push(
//     context,
//     MaterialPageRoute(
//       builder: (_) => WordMeaningScreen(
//         word: option["word"],
//         type: option["type"],
//         meaning: option["meaning"],
//         image: option["image"],
//        correct: correctCount, // Pass current score
//        total: questions.length, // Total questions

//       ),
//     ),
//   );
//                     } else {
//                       // 🔚 session finished
//                       debugPrint("🎯 Session complete");

//                       var count=                      correctCount ; // ✅ Reset score for next session


// Navigator.push(
//   context,
//   MaterialPageRoute(
//     builder: (_) => WordMeaningScreen(
//       word: option["word"],
//       type: option["type"],
//       meaning: option["meaning"],
//       image: option["image"],
//          correct: correctCount, // Pass current score
//        total: questions.length, // Total questions
//     ),
//   ),
// );


// loadQuestions();



//                     }
//                   },
//                   style: ElevatedButton.styleFrom(
//                     backgroundColor: accentColor,
//                     shape: RoundedRectangleBorder(
//                         borderRadius: BorderRadius.circular(14)),
//                   ),
//                   child: const Text(
//                     "Next ▶",
//                     style: TextStyle(
//                         color: Colors.black,
//                         fontWeight: FontWeight.bold),
//                   ),
//                 ),
//               ),
//             ],
//           ),
//         );
//       },
//     );
//   }

//   Widget optionCard(Map<String, dynamic> data) {
//     return Expanded(
//       child: GestureDetector(
//         onTap: () => selectOption(data),
//         child: Container(
//           margin: const EdgeInsets.symmetric(horizontal: 8),
//           padding: const EdgeInsets.all(14),
//           decoration: BoxDecoration(
//             borderRadius: BorderRadius.circular(22),
//             border: Border.all(color: accentColor.withOpacity(0.5)),
//           ),
//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.center,
//             children: [
//               Image.network(
//                 data["image"],
//                 height: 100,
//                 fit: BoxFit.cover,
//                 errorBuilder: (_, __, ___) => const Icon(
//                   Icons.image,
//                   color: Colors.white24,
//                   size: 60,
//                 ),
//               ),
//               const SizedBox(height: 20),
//               Text(
//                 data["word"].toUpperCase(),
//                 textAlign: TextAlign.center,
//                 style: TextStyle(
//                   color: Colors.white,
//                   fontSize: 24,
//                   fontWeight: FontWeight.w700,
//                   letterSpacing: 1.4,
//                   shadows: [
//                     Shadow(
//                       color: Colors.cyanAccent.withOpacity(0.6),
//                       blurRadius: 12,
//                     ),
//                   ],
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     if (loading) {
//       return const Scaffold(
//         backgroundColor: backgroundColor,
//         body: Center(
//           child: CircularProgressIndicator(color: accentColor),
//         ),
//       );
//     }

//     final current = questions[currentIndex];

//     return Scaffold(
//       backgroundColor: backgroundColor,
//       body: SafeArea(
//         child: Column(
//           children: [
//             const SizedBox(height: 16),
//             const Text(
//               "Listen & Choose",
//               style: TextStyle(
//                 color: textColor,
//                 fontSize: 26,
//                 fontWeight: FontWeight.bold,
//               ),
//             ),
//             const SizedBox(height: 20),

//             // 🔊 SPEAKER
//             Expanded(
//               flex: 3,
//               child: Center(
//                 child: ScaleTransition(
//                   scale: speakerPulse,
//                   child: GestureDetector(
//                     onTap: speak,
//                     child: Container(
//                       height: 110,
//                       width: 110,
//                       decoration: BoxDecoration(
//                         shape: BoxShape.circle,
//                         color: accentColor,
//                         boxShadow: [
//                           BoxShadow(color: glowColor, blurRadius: 45),
//                         ],
//                       ),
//                       child: const Icon(
//                         Icons.volume_up,
//                         size: 48,
//                         color: Colors.black,
//                       ),
//                     ),
//                   ),
//                 ),
//               ),
//             ),

//             // 🎴 OPTIONS
//             Expanded(
//               flex: 2,
//               child: ScaleTransition(
//                 scale: optionScale,
//                 child: Row(
//                   children: [
//                     optionCard(current["correct"]),
//                     optionCard(current["wrong"]),
//                   ],
//                 ),
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   @override
//   void dispose() {
//     speakerController.dispose();
//     optionController.dispose();
//     super.dispose();
//   }
// }






// class ListenSelectScreen extends StatefulWidget {
//   const ListenSelectScreen({super.key});

//   @override
//   State<ListenSelectScreen> createState() => _ListenSelectScreenState();
// }

// class _ListenSelectScreenState extends State<ListenSelectScreen>
//     with TickerProviderStateMixin {
//   final FlutterTts tts = FlutterTts();
//   final OpenAIService _ai = OpenAIService();

//   // 🎨 THEME
//   static const Color backgroundColor = Colors.black;
//   static const Color accentColor = Colors.cyanAccent;
//   static const Color glowColor = Color(0xFF80FFFF);
//   static const Color textColor = Colors.white;

//   bool loading = true;
//   late String word;
//   late String correct;
//   List<Map<String, dynamic>> options = [];

//   late AnimationController screenController;
//   late AnimationController speakerController;
//   late AnimationController optionController;
//   late AnimationController resultController;

//   late Animation<double> fadeAnim;
//   late Animation<Offset> slideAnim;
//   late Animation<double> speakerPulse;
//   late Animation<double> optionScale;
//   late Animation<double> resultScale;

//   @override
//   void initState() {
//     super.initState();

//     screenController =
//         AnimationController(vsync: this, duration: const Duration(milliseconds: 700));
//     speakerController =
//         AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
//     optionController =
//         AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
//     resultController =
//         AnimationController(vsync: this, duration: const Duration(milliseconds: 500));

//     fadeAnim = CurvedAnimation(parent: screenController, curve: Curves.easeIn);
//     slideAnim = Tween(begin: const Offset(0, 0.2), end: Offset.zero)
//         .animate(CurvedAnimation(parent: screenController, curve: Curves.easeOut));

//     speakerPulse = Tween(begin: 1.0, end: 1.15).animate(
//       CurvedAnimation(parent: speakerController, curve: Curves.easeInOut),
//     );

//     optionScale =
//         CurvedAnimation(parent: optionController, curve: Curves.elasticOut);
//     resultScale =
//         CurvedAnimation(parent: resultController, curve: Curves.elasticOut);

//     tts.setLanguage("en-IN");
//     tts.setSpeechRate(0.45);

//     screenController.forward();
//     loadQuestion();
//   }

//   // ================= AI =================
//   Future<void> loadQuestion() async {
//     try {
//       setState(() => loading = true);

//       final data = await _ai.getListenSelectQuestions();

//       final List<Map<String, dynamic>> loadedOptions = [];

//       for (final opt in data["options"]) {
//         final img = await OpenAIService.generateImage(opt["image_prompt"]);
//         loadedOptions.add({
//           "label": opt["label"],
//           "image": img,
//         });
//       }

//       setState(() {
//         word = data["word"];
//         correct = data["correct"];
//         options = loadedOptions;
//         loading = false;
//       });

//       optionController.forward(from: 0);
//     } catch (e) {
//       debugPrint("❌ AI Load Error: $e");
//       setState(() => loading = false);
//     }
//   }

//   // 🔊 SPEAK
//   void speak() async {
//     speakerController.repeat(reverse: true);
//     await tts.speak(word);
//     speakerController.stop();
//     speakerController.reset();
//   }

//   // ✅ SELECT
//   void select(String label) {
//     final bool isCorrect = label == correct;
//     resultController.forward(from: 0);

//     showModalBottomSheet(
//       context: context,
//       backgroundColor: Colors.transparent,
//       isDismissible: false,
//       builder: (_) {
//         return ScaleTransition(
//           scale: resultScale,
//           child: Container(
//             height: MediaQuery.of(context).size.height * 0.35,
//             padding: const EdgeInsets.all(24),
//             decoration: BoxDecoration(
//               borderRadius:
//                   const BorderRadius.vertical(top: Radius.circular(30)),
//               gradient: LinearGradient(
//                 colors: isCorrect
//                     ? [Colors.green, Colors.green.shade900]
//                     : [Colors.red, Colors.red.shade900],
//               ),
//             ),
//             child: Column(
//               children: [
//                 Icon(
//                   isCorrect ? Icons.verified : Icons.error,
//                   size: 70,
//                   color: Colors.white,
//                 ),
//                 const SizedBox(height: 12),
//                 Text(
//                   isCorrect ? "Excellent!" : "Try Again!",
//                   style: const TextStyle(
//                       color: Colors.white,
//                       fontSize: 26,
//                       fontWeight: FontWeight.bold),
//                 ),
             
//                 const Spacer(),
//                 SizedBox(
//                   width: double.infinity,
//                   height: 52,
//                   child: ElevatedButton(
//                     onPressed: () {
//                       Navigator.pop(context);
//                       Navigator.pushReplacement(
//                         context,
//                         MaterialPageRoute(
//                             builder: (context) => const WordMeaningScreen()),
//                       );
//                       // loadQuestion();
//                     },
//                     style: ElevatedButton.styleFrom(
//                       backgroundColor: accentColor,
//                       shape: RoundedRectangleBorder(
//                           borderRadius: BorderRadius.circular(14)),
//                     ),
//                     child: const Text(
//                       "Next ▶",
//                       style: TextStyle(
//                           color: Colors.black,
//                           fontWeight: FontWeight.bold),
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         );
//       },
//     );
//   }

//   // 🧠 IMAGE OR SMART WORD VISUAL
//   Widget safeImage(String? path, String label) {
//     if (path != null && path.startsWith("http")) {
//       return Image.network(
//         path,
//         height: 100,
//         fit: BoxFit.cover,
//         errorBuilder: (_, __, ___) => _wordVisual(label),
//       );
//     }

//     if (path != null &&
//         path.isNotEmpty &&
//         File(path).existsSync()) {
//       return Image.file(
//         File(path),
//         height: 100,
//         width: 100,
//         fit: BoxFit.cover,
//         errorBuilder: (_, __, ___) => _wordVisual(label),
//       );
//     }

//     return _wordVisual(label);
//   }

//   Widget _wordVisual(String word) {
//     final String letter =
//         word.isNotEmpty ? word[0].toUpperCase() : "?";
//     final Color bg = _colorFromWord(word);

//     return Container(
//       height: 100,
//       width: double.infinity,
//       alignment: Alignment.center,
//       decoration: BoxDecoration(
//         borderRadius: BorderRadius.circular(22),
//         gradient: LinearGradient(
//           colors: [bg.withOpacity(0.9), bg.withOpacity(0.6)],
//         ),
//         boxShadow: [
//           BoxShadow(
//             color: bg.withOpacity(0.6),
//             blurRadius: 18,
//             offset: const Offset(0, 8),
//           ),
//         ],
//       ),
//       child: Text(
//         letter,
//         style: const TextStyle(
//           fontSize: 46,
//           color: Colors.white,
//           fontWeight: FontWeight.bold,
//         ),
//       ),
//     );
//   }

//   Color _colorFromWord(String word) {
//     final colors = [
//       Colors.redAccent,
//       Colors.blueAccent,
//       Colors.greenAccent,
//       Colors.orangeAccent,
//       Colors.purpleAccent,
//       Colors.tealAccent,
//       Colors.cyanAccent,
//     ];
//     int index = word.codeUnits.fold(0, (a, b) => a + b);
//     return colors[index % colors.length];
//   }

//   @override
//   Widget build(BuildContext context) {
//     if (loading) {
//       return const Scaffold(
//         backgroundColor: backgroundColor,
//         body: Center(
//             child: CircularProgressIndicator(color: accentColor)),
//       );
//     }

//     return Scaffold(
//       backgroundColor: backgroundColor,
//       body: SafeArea(
//         child: FadeTransition(
//           opacity: fadeAnim,
//           child: SlideTransition(
//             position: slideAnim,
//             child: Column(
//               children: [
//                 const SizedBox(height: 16),
//                 const Text("Listen & Choose",
//                     style: TextStyle(
//                         color: textColor,
//                         fontSize: 26,
//                         fontWeight: FontWeight.bold)),
//                 const SizedBox(height: 20),

//                 // 🔊 SPEAKER
//                 Expanded(
//                   flex: 3,
//                   child: Center(
//                     child: ScaleTransition(
//                       scale: speakerPulse,
//                       child: GestureDetector(
//                         onTap: speak,
//                         child: Container(
//                           height: 110,
//                           width: 110,
//                           decoration: BoxDecoration(
//                             shape: BoxShape.circle,
//                             color: accentColor,
//                             boxShadow: [
//                               BoxShadow(
//                                   color: glowColor, blurRadius: 45)
//                             ],
//                           ),
//                           child: const Icon(Icons.volume_up,
//                               size: 48, color: Colors.black),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),

//                 // 🎴 OPTIONS
//                 Expanded(
//                   flex: 2,
//                   child: ScaleTransition(
//                     scale: optionScale,
//                     child: Row(
//                       children: options.map((o) {
//                         return Expanded(
//                           child: GestureDetector(
//                             onTap: () => select(o["label"]),
//                             child: Container(
//                               margin:
//                                   const EdgeInsets.symmetric(horizontal: 8),
//                               padding: const EdgeInsets.all(14),
//                               decoration: BoxDecoration(
//                                 borderRadius: BorderRadius.circular(22),
//                                 border: Border.all(
//                                     color:
//                                         accentColor.withOpacity(0.5)),
//                               ),
//                               child: Column(
//                                 mainAxisAlignment:
//                                     MainAxisAlignment.center,
//                                 children: [
//                                   safeImage(o["image"], o["label"]),
//                                   const SizedBox(height: 20),
//                                  Text(
//   o["label"].toUpperCase(),
//   textAlign: TextAlign.center,
//   style: TextStyle(
//     color: Colors.white,
//     fontSize: 24,
//     fontWeight: FontWeight.w700,
//     letterSpacing: 1.4, // 🔥 premium spacing
//     shadows: [
//       Shadow(
//         color: Colors.cyanAccent.withOpacity(0.6),
//         blurRadius: 12,
//         offset: const Offset(0, 0),
//       ),
//     ],
//   ),
// ),

//                                 ],
//                               ),
//                             ),
//                           ),
//                         );
//                       }).toList(),
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }

//   @override
//   void dispose() {
//     screenController.dispose();
//     speakerController.dispose();
//     optionController.dispose();
//     resultController.dispose();
//     super.dispose();
//   }
// }





// class ListenSelectScreen extends StatefulWidget {
//   const ListenSelectScreen({super.key});

//   @override
//   State<ListenSelectScreen> createState() => _ListenSelectScreenState();
// }

// class _ListenSelectScreenState extends State<ListenSelectScreen>
//     with TickerProviderStateMixin {
//   final FlutterTts tts = FlutterTts();

//   // 🎨 THEME COLORS
//   static const Color backgroundColor = Colors.black;
//   static const Color accentColor = Colors.cyanAccent;
//   static const Color glowColor = Color(0xFF80FFFF);
//   static const Color textColor = Colors.white;

//   bool loading = true;
//   late String word;
//   late String correct;
//   List<Map<String, dynamic>> options = [];

//   late AnimationController screenController;
//   late AnimationController speakerController;
//   late AnimationController optionController;
//   late AnimationController resultController;

//   late Animation<double> fadeAnim;
//   late Animation<Offset> slideAnim;
//   late Animation<double> speakerPulse;
//   late Animation<double> optionScale;
//   late Animation<double> resultScale;

//   @override
//   void initState() {
//     super.initState();

//     screenController =
//         AnimationController(vsync: this, duration: const Duration(milliseconds: 700));
//     speakerController =
//         AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
//     optionController =
//         AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
//     resultController =
//         AnimationController(vsync: this, duration: const Duration(milliseconds: 500));

//     fadeAnim = CurvedAnimation(parent: screenController, curve: Curves.easeIn);
//     slideAnim = Tween(begin: const Offset(0, 0.2), end: Offset.zero)
//         .animate(CurvedAnimation(parent: screenController, curve: Curves.easeOut));

//     speakerPulse =
//         Tween(begin: 1.0, end: 1.15).animate(
//           CurvedAnimation(parent: speakerController, curve: Curves.easeInOut),
//         );

//     optionScale =
//         CurvedAnimation(parent: optionController, curve: Curves.elasticOut);
//     resultScale =
//         CurvedAnimation(parent: resultController, curve: Curves.elasticOut);

//     tts.setLanguage("en-US");
//     tts.setSpeechRate(0.45);

//     screenController.forward();
//     loadQuestion(); // 🔥 AI CALL
//   }
//   final OpenAIService _ai = OpenAIService();


//   // ================== 🔥 AI CONNECTED FUNCTION ==================
//   Future<void> loadQuestion() async {
//     try {
//       setState(() => loading = true);

//       // 1️⃣ Get word + options
// final data = await _ai.getListenSelectQuestion();

//       final List<Map<String, dynamic>> loadedOptions = [];

//       // 2️⃣ Generate image for each option
//       for (final opt in data["options"]) {
//         final img =
//             await OpenAIService.generateImage(opt["image_prompt"]);

//         loadedOptions.add({
//           "label": opt["label"],
//           "image": img,
//         });
//       }

//       setState(() {
//         word = data["word"];
//         correct = data["correct"];
//         options = loadedOptions;
//         loading = false;
//       });

//       optionController.forward(from: 0);
//     } catch (e) {
//       debugPrint("❌ AI Load Error: $e");
//       setState(() => loading = false);
//     }
//   }

//   // 🔊 SPEAK
//   void speak() async {
//     speakerController.repeat(reverse: true);
//     await tts.speak(word);
//     speakerController.stop();
//     speakerController.reset();
//   }

//   // ✅ SELECT
//   void select(String label) {
//     final bool isCorrect = label == correct;
//     resultController.forward(from: 0);

//     showModalBottomSheet(
//       context: context,
//       backgroundColor: Colors.transparent,
//       isDismissible: false,
//       builder: (_) {
//         return ScaleTransition(
//           scale: resultScale,
//           child: Container(
//             height: MediaQuery.of(context).size.height * 0.55,
//             padding: const EdgeInsets.all(24),
//             decoration: BoxDecoration(
//               borderRadius:
//                   const BorderRadius.vertical(top: Radius.circular(30)),
//               gradient: LinearGradient(
//                 colors: isCorrect
//                     ? [Colors.green, Colors.green.shade900]
//                     : [Colors.red, Colors.red.shade900],
//               ),
//             ),
//             child: Column(
//               children: [
//                 Icon(
//                   isCorrect ? Icons.verified : Icons.error,
//                   size: 70,
//                   color: Colors.white,
//                 ),
//                 const SizedBox(height: 12),
//                 Text(
//                   isCorrect ? "Excellent!" : "Try Again!",
//                   style: const TextStyle(
//                       color: Colors.white,
//                       fontSize: 26,
//                       fontWeight: FontWeight.bold),
//                 ),
//                 const SizedBox(height: 10),
//                 Text(
//                   "\"$word\"",
//                   style: const TextStyle(color: Colors.white70),
//                 ),
//                 const Spacer(),
//                 SizedBox(
//                   width: double.infinity,
//                   height: 52,
//                   child: ElevatedButton(
//                     onPressed: () {
//                       Navigator.pop(context);
//                       loadQuestion();
//                     },
//                     style: ElevatedButton.styleFrom(
//                       backgroundColor: accentColor,
//                       shape: RoundedRectangleBorder(
//                           borderRadius: BorderRadius.circular(14)),
//                     ),
//                     child: const Text(
//                       "Next ▶",
//                       style: TextStyle(
//                           color: Colors.black, fontWeight: FontWeight.bold),
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         );
//       },
//     );
//   }

//   // 🖼️ IMAGE SAFE
//   Widget safeImage(String? path) {
//     if (path == null || path.isEmpty) {
//       return const Icon(Icons.image_not_supported,
//           color: Colors.white24, size: 80);
//     }
//     if (path.startsWith("http")) {
//       return Image.network(path, height: 100);
//     }
//     return Image.file(File(path), height: 100);
//   }

//   @override
//   Widget build(BuildContext context) {
//     if (loading) {
//       return const Scaffold(
//         backgroundColor: backgroundColor,
//         body: Center(
//             child: CircularProgressIndicator(color: accentColor)),
//       );
//     }

//     return Scaffold(
//       backgroundColor: backgroundColor,
//       body: SafeArea(
//         child: FadeTransition(
//           opacity: fadeAnim,
//           child: SlideTransition(
//             position: slideAnim,
//             child: Column(
//               children: [
//                 const SizedBox(height: 16),
//                 const Text("Listen & Choose",
//                     style: TextStyle(
//                         color: textColor,
//                         fontSize: 26,
//                         fontWeight: FontWeight.bold)),
//                 const SizedBox(height: 20),

//                 // 🔊 SPEAKER
//                 Expanded(
//                   flex: 3,
//                   child: Center(
//                     child: ScaleTransition(
//                       scale: speakerPulse,
//                       child: GestureDetector(
//                         onTap: speak,
//                         child: Container(
//                           height: 110,
//                           width: 110,
//                           decoration: BoxDecoration(
//                             shape: BoxShape.circle,
//                             color: accentColor,
//                             boxShadow: [
//                               BoxShadow(
//                                   color: glowColor,
//                                   blurRadius: 45)
//                             ],
//                           ),
//                           child: const Icon(Icons.volume_up,
//                               size: 48, color: Colors.black),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),

//                 // 🎴 OPTIONS
//                 Expanded(
//                   flex: 4,
//                   child: ScaleTransition(
//                     scale: optionScale,
//                     child: Row(
//                       children: options.map((o) {
//                         return Expanded(
//                           child: GestureDetector(
//                             onTap: () => select(o["label"]),
//                             child: Container(
//                               margin:
//                                   const EdgeInsets.symmetric(horizontal: 8),
//                               padding: const EdgeInsets.all(14),
//                               decoration: BoxDecoration(
//                                 borderRadius: BorderRadius.circular(22),
//                                 border: Border.all(
//                                     color: accentColor.withOpacity(0.6)),
//                               ),
//                               child: Column(
//                                 mainAxisAlignment:
//                                     MainAxisAlignment.center,
//                                 children: [
//                                   safeImage(o["image"]),
//                                   const SizedBox(height: 10),
//                                   Text(o["label"],
//                                       style: const TextStyle(
//                                           color: Colors.white,
//                                           fontSize: 16)),
//                                 ],
//                               ),
//                             ),
//                           ),
//                         );
//                       }).toList(),
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }

//   @override
//   void dispose() {
//     screenController.dispose();
//     speakerController.dispose();
//     optionController.dispose();
//     resultController.dispose();
//     super.dispose();
//   }
// }



