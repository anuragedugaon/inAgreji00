import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart' show SharedPreferences;

import '../../config/openai_config.dart';
import '../ai_teacher/ai_service.dart';

class OpenAIService {

  

final List<String> _modelFallbacks = [
  "gpt-4o-mini",     // paid, fast, cheap fallback
  "o3-mini",         // strong reasoning fallback
  "gpt-4o",          // high-quality fallback
  "gpt-3.5-turbo",   // legacy fallback
];
static const String _apiUrl = "https://api.openai.com/v1/chat/completions";


static final Set<String> _usedWords = {};


// ===================== LISTEN & SELECT ===================================



Future<List<Map<String, dynamic>>> getListenSelectQuestions() async {
  final prefs = await SharedPreferences.getInstance();
  final userLevel = prefs.getString('selected_level') ?? 'beginner';
final selectedLangCode =
      prefs.getString('selected_language_code')?.toLowerCase() ; 
       final progress = await LearningProgression.today();
  final selectedLangName =
      prefs.getString('selected_language') ;
  // 🔥 UNIQUE SESSION ID
  final String sessionId =
      DateTime.now().millisecondsSinceEpoch.toString();

  for (final modelName in _modelFallbacks) {
    try {
      final response = await http.post(
        Uri.parse(_apiUrl),
        headers: {
          "Authorization": "Bearer ${OpenAIConfig.apiKey}",
          "Content-Type": "application/json",
        },
        body: jsonEncode({
          "model": modelName,
          "messages": [
            {
              "role": "system",
              "content": """
Return ONLY valid JSON.
No markdown. No explanation.

THIS IS A STRICT TEST.

SESSION_ID: $sessionId

CRITICAL RULES (NO EXCEPTIONS):
- Treat this as a COMPLETELY NEW session.
- You MUST NOT repeat ANY word that has EVER been used before.
- If a word is even slightly similar, DO NOT use it.

ABSOLUTELY FORBIDDEN:
- Reusing common words like: go, come, see, meet, take, give, eat, drink, walk, run
- Reusing any word from earlier sessions (assume thousands already used)

HARD CONSTRAINTS:
- correct.word ≠ wrong.word
- ALL words must be UNIQUE across the ENTIRE response
- If unsure, invent a DIFFERENT common daily word instead
IMPORTANT LANGUAGE RULE:
- English words are for learning.
- You MUST ALSO provide the word name in the selected app language.
- The app language is: $selectedLangName ($selectedLangCode)

FORMAT (JSON ONLY):
IMPORTANT:
- This is a NEW learning session.
- Do NOT reuse any words from earlier sessions.
- Treat this request as completely fresh.

RULES:
- correct.word and wrong.word must be DIFFERENT.
- All words must be UNIQUE INSIDE this response only.

FORMAT:
{
  "questions": [
    {
      "correct": {
        "word": "meet",
          "local_word": "Same word name in $selectedLangCode",

        "type": "verb",
        "meaning": "to come together",
        "image": "https://source.unsplash.com/800x600/?meet,people"
      },
      "wrong": {
        "word": "see",
  "image": "https://images.unsplash.com/search/photos?query=ENGLISH_WORD"

        "type": "verb",
        "meaning": "to look at something with the eyes",
  "image": "https://images.unsplash.com/search/photos?query=ENGLISH_WORD"
      }
    }
  ]
}
"""
            },
            {
              "role": "user",
              "content": """
Student level: $userLevel
Difficulty stage: ${progress.stage}

Session: $sessionId
Give 5 NEW very common daily English words.
Use spoken English only.
"""
            }
          ],
          "temperature": 0.6,
          "max_tokens": 700,
        }),
      );

      if (response.statusCode != 200) continue;

      final raw =
          jsonDecode(response.body)["choices"][0]["message"]["content"];

      final decoded = jsonDecode(raw);
      final List questions = decoded["questions"] ?? [];

      final Set<String> localUsed = {};
      final List<Map<String, dynamic>> result = [];

      for (final q in questions) {
        final correct =
            q["correct"]?["word"]?.toString().toLowerCase().trim() ?? "";
        final wrong =
            q["wrong"]?["word"]?.toString().toLowerCase().trim() ?? "";

        if (correct.isEmpty || wrong.isEmpty) continue;
        if (correct == wrong) continue;

        if (localUsed.contains(correct) ||
            localUsed.contains(wrong)) continue;

        localUsed.add(correct);
        localUsed.add(wrong);

        result.add(Map<String, dynamic>.from(q));
      }

      if (result.isNotEmpty) return result;
    } catch (e) {
      debugPrint("❌ ListenSelect AI error: $e");
    }
  }

  // 🔴 FALLBACK (SAFE)
  return [
    {
      "correct": {
        "word": "apple",
        "type": "noun",
        "meaning": "a fruit",
        "image": "https://source.unsplash.com/800x600/?apple,fruit"
      },
      "wrong": {
        "word": "chair",
        "type": "noun",
        "meaning": "something to sit on",
        "image": "https://source.unsplash.com/800x600/?chair,furniture"
      }
    }
  ];
}






// ===================== SWIPE CARD =====================



Future<List<Map<String, dynamic>>> getSwipeCardQuestions() async {
  final prefs = await SharedPreferences.getInstance();
  final userLevel = prefs.getString('selected_level') ?? 'beginner';
  final progress = await LearningProgression.today();
   final selectedLangCode =
      prefs.getString('selected_language_code')?.toLowerCase() ; 
  final selectedLangName =
      prefs.getString('selected_language') ;

  // 🔥 UNIQUE SESSION ID (har session naya)
  final String sessionId =
      DateTime.now().millisecondsSinceEpoch.toString();

  for (final modelName in _modelFallbacks) {
    try {
      final response = await http.post(
        Uri.parse(_apiUrl),
        headers: {
          "Authorization": "Bearer ${OpenAIConfig.apiKey}",
          "Content-Type": "application/json",
        },
        body: jsonEncode({
          "model": modelName,
          "messages": [
            {
              "role": "system",
              "content": """
Return ONLY valid JSON.
No markdown. No explanation.

SESSION_ID: $sessionId
IMPORTANT:
- This is a NEW learning session.
- Do NOT reuse any sentence or answers from earlier sessions.
- Treat this request as completely fresh.

RULES:
- Use very simple daily English.
- Only ONE blank per sentence.
- Correct answer must be grammatically correct.
- Wrong answer must be realistic but incorrect.
- NO repetition inside this response.
- App language is: $selectedLangName ($selectedLangCode)


FORMAT:
{
  "questions": [
    {
      "sentence_en": "Nice ____ meet you.",
      "sentence_local": "Same sentence meaning in app language with ____",

      "correct": "to",
      "wrong": "in"
    }
  ]
}
"""
            },
            {
              "role": "user",
              "content": """
Student level: $userLevel
Difficulty stage: ${progress.stage}

Session: $sessionId
Generate 5 NEW swipe card questions.
Use spoken English only.
"""
            }
          ],
          "temperature": 0.6, // 🔥 thoda variation
          "max_tokens": 500,
        }),
      );

      if (response.statusCode != 200) continue;

      final raw =
    jsonDecode(response.body)["choices"][0]["message"]["content"];

final decoded = jsonDecode(raw);
final List questions = decoded["questions"] ?? [];

final Set<String> usedSentences = {};
final Set<String> usedWords = {};
final List<Map<String, dynamic>> result = [];

for (final q in questions) {
  final sentenceEn =
      q["sentence_en"]?.toString().trim() ?? "";
  final sentenceLocal =
      q["sentence_local"]?.toString().trim() ?? "";
  final correct =
      q["correct"]?.toString().toLowerCase().trim() ?? "";
  final wrong =
      q["wrong"]?.toString().toLowerCase().trim() ?? "";

  // ❌ empty check
  if (sentenceEn.isEmpty ||
      sentenceLocal.isEmpty ||
      correct.isEmpty ||
      wrong.isEmpty) continue;

  // ❌ same answer
  if (correct == wrong) continue;

  // ❌ duplicate sentence
  final sentenceKey = sentenceEn.toLowerCase();
  if (usedSentences.contains(sentenceKey)) continue;

  // ❌ duplicate answers
  if (usedWords.contains(correct) ||
      usedWords.contains(wrong)) continue;

  usedSentences.add(sentenceKey);
  usedWords.add(correct);
  usedWords.add(wrong);

  result.add({
    "sentence_en": sentenceEn,
    "sentence_local": sentenceLocal,
    "correct": q["correct"],
    "wrong": q["wrong"],
  });
}
      if (result.isNotEmpty) return result;
    } catch (e) {
      debugPrint("❌ SwipeCard AI error: $e");
    }
  }

  // 🔴 FALLBACK (SAFE)
  return [
    {
      "sentence": "Nice ____ meet you.",
        "sentence_local": "आपसे ____ मिलकर खुशी हुई।",

      "correct": "to",
      "wrong": "in"
    }
  ];
}




// ===================== SPEAKING PRACTICE =====================


Future<List<Map<String, dynamic>>> getSpeakingPracticeQuestions() async {
  final prefs = await SharedPreferences.getInstance();
  final userLevel = prefs.getString('selected_level') ?? 'beginner';
  final progress = await LearningProgression.today();
  final selectedLangCode =
      prefs.getString('selected_language_code')?.toLowerCase() ; 
  final selectedLangName =
      prefs.getString('selected_language') ;

  final String sessionId =
      DateTime.now().millisecondsSinceEpoch.toString();

  for (final modelName in _modelFallbacks) {
    try {
      final response = await http.post(
        Uri.parse(_apiUrl),
        headers: {
          "Authorization": "Bearer ${OpenAIConfig.apiKey}",
          "Content-Type": "application/json",
        },
      
        body: jsonEncode({
          "model": modelName,
          "messages": [
            {
              "role": "system",
              "content": """
Return ONLY valid JSON.
No markdown. No explanation.

SESSION_ID: $sessionId
IMPORTANT:
- This is a NEW learning session.
- Ignore all previous outputs.
- Do NOT reuse any sentence, prompt, or hint from earlier sessions.

RULES:
- Use very simple spoken English.
- Sentence length: 3 to 6 words.
- Easy for beginners to speak.
- NO repetition inside this response.

FORMAT:
{
  "questions": [
    {
      "prompt": "Greet someone politely",
      "sentence": "Nice to meet you",
      "hint": "Nice to ___ you"
    }
  ]
}
"""
            },
            {
              "role": "user",
              "content": """
Student level: $userLevel
Difficulty stage: ${progress.stage}

Session: $sessionId
Generate 5 NEW speaking practice questions.
"""
            }
          ],
          "temperature": 0.6,
          "max_tokens": 500,
        }),
      
      
      );

      if (response.statusCode != 200) continue;

      final raw =
          jsonDecode(response.body)["choices"][0]["message"]["content"];

      final decoded = jsonDecode(raw);
      final List questions = decoded["questions"] ?? [];

      final Set<String> usedSentences = {};
      final Set<String> usedPrompts = {};
      final Set<String> usedHints = {};
      final List<Map<String, dynamic>> result = [];

      for (final q in questions) {
        final prompt =
            q["prompt"]?.toString().toLowerCase().trim() ?? "";
        final sentence =
            q["sentence"]?.toString().toLowerCase().trim() ?? "";
        final hint =
            q["hint"]?.toString().toLowerCase().trim() ?? "";

        if (prompt.isEmpty || sentence.isEmpty || hint.isEmpty) continue;

        final wc = sentence.split(" ").length;
        if (wc < 3 || wc > 6) continue;

        if (usedPrompts.contains(prompt) ||
            usedSentences.contains(sentence) ||
            usedHints.contains(hint)) continue;

        usedPrompts.add(prompt);
        usedSentences.add(sentence);
        usedHints.add(hint);

        result.add({
          "prompt": q["prompt"],
          "sentence": q["sentence"],
          "hint": q["hint"],
        });
      }

      if (result.isNotEmpty) return result;
    } catch (e) {
      debugPrint("❌ SpeakingPractice AI error: $e");
    }
  }

  return [
    {
      "prompt": "Greet someone",
      "sentence": "Nice to meet you",
      "hint": "Nice to ___ you"
    }
  ];
}



Future<String?> getImageForWord(String word) async {
  final response = await http.get(
    Uri.parse(
      "https://api.pexels.com/v1/search?query=$word&per_page=1",
    ),
    headers: {
      "Authorization":
          "Z0HNmGdJGDvpJGRD7o6gfweKRLlILX7Wx8aIE4uE5aXSdy85haDyuHOt",
    },
  );

  if (response.statusCode == 200) {
    final data = jsonDecode(response.body);

    if (data["photos"] != null && data["photos"].isNotEmpty) {
      return data["photos"][0]["src"]["medium"];
    }
  }

  return null;
}

// Future<String?> getImageForWord(String word) async {
//   final url =
//       "https://api.pexels.com/v1/search?query=$word&per_page=1";

//   final response = await http.get(
//     Uri.parse(url),
//     headers: {
//       "Authorization":
//           "Z0HNmGdJGDvpJGRD7o6gfweKRLlILX7Wx8aIE4uE5aXSdy85haDyuHOt",
//     },
//   );

//   debugPrint("🖼️ Unsplash response: ${response.body}");

//   if (response.statusCode == 200) {
//     final data = jsonDecode(response.body);
//     if (data["results"] != null && data["results"].isNotEmpty) {
//       return data["results"][0]["urls"]["regular"];
//     }
//   }

//   return null;
// }



static Future<String> generateImage(String prompt) async {
  final response = await http.post(
    Uri.parse("https://api.openai.com/v1/images/generations"),
    headers: {
      "Authorization": "Bearer ${OpenAIConfig.apiKey}",
      "Content-Type": "application/json",
    },
    body: jsonEncode({
      "model": "gpt-image-1",
      "prompt": prompt,
    }),
  );

  debugPrint("🖼️ Image response: ${response.body}");

  final decoded = jsonDecode(response.body);

  if (decoded["error"] != null) {
    debugPrint("❌ Image API Error: ${decoded["error"]["message"]}");
    return _placeholder();
  }

  if (decoded["data"] == null || decoded["data"].isEmpty) {
    return _placeholder();
  }

  final image = decoded["data"][0];

  // Most common response = base64
  if (image["b64_json"] != null) {
    final bytes = base64Decode(image["b64_json"]);
    return await _saveTempImage(bytes);
  }

  // Sometimes URL
  if (image["url"] != null) {
    return image["url"];
  }

  return _placeholder();
}


// // Model fallbacks
// static Future<String> generateImage(String prompt) async {
//   String buildPrompt(String word) {
//   return '''
// Create a clear, simple, realistic illustration that represents the English word "$word".
// Suitable for English vocabulary learning.
// Single meaning, everyday context, no text, no letters, no watermark.
// ''';
// }

//   final response = await http.post(
//     Uri.parse("https://api.openai.com/v1/responses"),
//     headers: {
//       "Authorization": "Bearer ${OpenAIConfig.apiKey}",
//       "Content-Type": "application/json",
//     },
//     body: jsonEncode({
//       "model": "gpt-image-1",
//       "input": buildPrompt(prompt),
//     }),
//   );

//   debugPrint("🖼️ Image response: ${response.body}");

//   final decoded = jsonDecode(response.body);
//     debugPrint(" Image API festh: ${decoded["error"]["message"]}");

//   // ❌ API error
//   if (decoded["error"] != null) {
//     debugPrint("❌ Image API Error: ${decoded["error"]["message"]}");
//     return _placeholder();
//   }

//   // 🔥 NEW RESPONSE STRUCTURE
//   final output = decoded["output"];
//   if (output == null || output.isEmpty) {
//     return _placeholder();
//   }

//   for (final item in output) {
//     if (item["content"] != null) {
//       for (final content in item["content"]) {
//         // ✅ BASE64 IMAGE
//         if (content["type"] == "output_image" &&
//             content["b64_json"] != null) {
//           final bytes = base64Decode(content["b64_json"]);
//           return await _saveTempImage(bytes);
//         }
//       }
//     }
//   }

//   return _placeholder();
// }


// 🔥 Save image locally & return path
static Future<String> _saveTempImage(Uint8List bytes) async {
  final dir = await getTemporaryDirectory();
  final file =
      File('${dir.path}/ai_img_${DateTime.now().millisecondsSinceEpoch}.png');
  await file.writeAsBytes(bytes);
  return file.path;
}

// fallback image
static String _placeholder() {
  return "https://via.placeholder.com/300?text=Image+Unavailable";
}


}
