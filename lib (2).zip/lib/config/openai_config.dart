class OpenAIConfig {
  static const String apiKey =
      "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";
}
