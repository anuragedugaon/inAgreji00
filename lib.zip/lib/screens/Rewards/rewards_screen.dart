import 'package:flutter/material.dart';
import 'package:inangreji_flutter/routes/app_routes.dart';

class RewardsScreen extends StatelessWidget {
  const RewardsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Theme Colors
    const Color backgroundColor = Colors.black;
    const Color accentColor = Colors.cyanAccent;
    const Color glowColor = Color(0xFF80FFFF);
    const Color textColor = Colors.white;
    const Color cardColor = Color(0xFF1C1C1E);
    const Color coinColor = Colors.orange;

    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        backgroundColor: backgroundColor,
        elevation: 0,
        centerTitle: true,
        title: const Text(
          "Rewards Store",
          style: TextStyle(
            color: accentColor,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),

      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            // ✅ Grammar Pack Reward
            _buildRewardCard(
              icon: Icons.menu_book,
              label: "Unlock Grammar Pack",
              price: 500,
              coinColor: coinColor,
            ),
            const SizedBox(height: 20),

            // ✅ Avatar Reward
            _buildRewardCard(
              icon: Icons.person,
              label: "New Avatar",
              price: 250,
              coinColor: coinColor,
            ),
          ],
        ),
      ),

      // ✅ Bottom Navigation Bar
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: 0, // highlight current tab (set accordingly per screen)
        onTap: (index) {
          switch (index) {
            case 0: // Home
              Navigator.pushReplacementNamed(context, AppRoutes.home);
              break;
            case 1: // store
              Navigator.pushReplacementNamed(context, AppRoutes.challenge);
              break;
            case 2: // Tips
              //Navigator.pushReplacementNamed(context, AppRoutes.rule);
              break;
            case 3: // Menu
              //Navigator.pushReplacementNamed(context, AppRoutes.menu);
              break;
          }
        },
        backgroundColor: cardColor,
        type: BottomNavigationBarType.fixed,
        selectedItemColor: accentColor,
        unselectedItemColor: Colors.white70,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: "Home",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.book),
            label: "Store",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.lightbulb),
            label: "AI",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.menu),
            label: "Profile",
          ),
        ],
      ),
    );
  }

  /// ✅ Reward Card Builder
  Widget _buildRewardCard({
    required IconData icon,
    required String label,
    required int price,
    required Color coinColor,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.cyanAccent, width: 1.5),
        boxShadow: [
          BoxShadow(
            color: Colors.cyanAccent.withOpacity(0.4),
            blurRadius: 8,
            spreadRadius: 1,
          ),
        ],
      ),
      child: Row(
        children: [
          Icon(icon, color: Colors.cyanAccent, size: 40),
          const SizedBox(width: 16),
          Expanded(
            child: Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Row(
            children: [
              Icon(Icons.monetization_on, color: coinColor, size: 22),
              const SizedBox(width: 4),
              Text(
                "$price",
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
