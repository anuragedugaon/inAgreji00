import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

import '../../config/openai_config.dart';

class AIService {
  static final AIService _instance = AIService._internal();
  factory AIService() => _instance;
   final stt.SpeechToText speech = stt.SpeechToText();

  AIService._internal() {
    _initTts();
  }

  static const String _apiUrl = 'https://api.openai.com/v1/chat/completions';
  final FlutterTts _tts = FlutterTts();
  double ttsRate = 0.45;
  ValueNotifier<int> currentWordIndex = ValueNotifier<int>(0);

  Future<void> _initTts() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final selectedLangCode =
          prefs.getString('selected_language_code')?.toLowerCase() ?? 'en';
      var voiceLocale = _getVoiceLocale(selectedLangCode);

      final voices = await _tts.getVoices;

      if (voices == null || voices.isEmpty) {
        debugPrint("⚠️ No TTS voices found, falling back to English");
        voiceLocale = 'en-IN';
      } else {
        Map<String, String>? matchedVoice;
        for (final v in voices) {
          if (v is Map) {
            final locale = v['locale']?.toString() ?? '';
            if (locale.startsWith(voiceLocale.split('-').first)) {
              matchedVoice = {
                'name': v['name']?.toString() ?? '',
                'locale': locale,
              };
              break;
            }
          }
        }

        if (matchedVoice != null) {
          await _tts.setVoice(matchedVoice);
        } else {
          debugPrint(
              "⚠️ No exact TTS match for $voiceLocale, fallback to English");
          voiceLocale = 'en-IN';
        }
      }

      await _tts.setLanguage(voiceLocale);
      await _tts.setSpeechRate(ttsRate);
      await _tts.setPitch(1.0);
      await _tts.awaitSpeakCompletion(true);
      debugPrint("🗣️ TTS initialized for language: $voiceLocale");
    } catch (e) {
      debugPrint("❌ TTS init error: $e");
    }
  }

  Future<void> refreshVoice() async {
    await _initTts();
    debugPrint("🔁 Voice reloaded for new language");
  }

  /// 🌍 Map app language code → TTS voice locale
  String _getVoiceLocale(String code) {
    switch (code) {
      case 'hi':
        return 'hi-IN'; // 🇮🇳 Hindi
      case 'bn':
        return 'bn-IN'; // 🇮🇳 Bengali
      case 'en':
      default:
        return 'en-IN'; // 🇮🇳 Indian English
    }
  }






  /// 🧠 Fetch AI answer — auto-translated to user language
  Future<String> getAnswer(String question) async {
    const String apiKey =
        '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';

    try {
      final prefs = await SharedPreferences.getInstance();
      final selectedLangCode =
          prefs.getString('selected_language_code')?.toLowerCase() ?? 'en';

      // 🧭 Tell OpenAI to respond in selected language
      final String languageInstruction =
          _getLanguageInstruction(selectedLangCode);

      final response = await http.post(
        Uri.parse(_apiUrl),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $apiKey',
        },
        body: jsonEncode({
          'model': 'gpt-4.1-mini',
          'messages': [
            {
              'role': 'system',
              'content': languageInstruction,
            },
            {'role': 'user', 'content': question},
          ],
          'max_tokens': 250,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final text = data['choices'][0]['message']['content'].trim();
        debugPrint("🤖 AI ($selectedLangCode): $text");
        return text;
      } else {
        return "I'm sorry, I couldn’t connect right now.";
      }
    } catch (e) {
      debugPrint('❌ Exception: $e');
      return "Please check your internet connection.";
    }
  }

  /// 🎯 Language-specific instruction for AI
  String _getLanguageInstruction(String code) {
    switch (code) {
      case 'hi':
        return 'You are a Hindi grammar and English teacher. Respond only in Hindi. When explaining English, use Hindi examples and translations.';
      case 'bn':
        return 'You are a Bengali grammar and English teacher. Respond only in Bengali. When explaining English, use Bengali examples and translations.';
      case 'en':
      default:
        return 'You are an English grammar teacher. Respond in clear English.';
    }
  }



  /// 🗣️ Speak text using the proper voice
  Future<void> speakText(
    String text, {
    VoidCallback? onStart,
    VoidCallback? onComplete,
  }) async {
    await _initTts();

    _tts.setStartHandler(() {
      debugPrint('🎙️ TTS started');
      onStart?.call();
    });

    _tts.setCompletionHandler(() {
      debugPrint('✅ TTS completed');
      onComplete?.call();
    });

    _tts.setErrorHandler((msg) {
      debugPrint('❌ TTS error: $msg');
      onComplete?.call();
    });

    await _tts.stop();

    try {
      await _tts.speak(text);
    } catch (e) {
      debugPrint('⚠️ Speak retry: $e');
      await Future.delayed(const Duration(seconds: 1));
      await _tts.speak(text);
    }
  }



  Future<void> stopSpeaking() async => _tts.stop();
  void dispose() => _tts.stop();


Future<String> listenVoice() async {
  String finalText = "";

  bool available = await speech.initialize(
    onError: (error) {
      print("Speech Error: $error");
    },
    onStatus: (status) {
      print("Speech Status: $status");
    },
  );

  if (!available) return "";

  await speech.listen(
    listenFor: const Duration(seconds: 8),
    pauseFor: const Duration(seconds: 3),
    partialResults: true, // 👈 IMPORTANT!
    onResult: (result) {
      finalText = result.recognizedWords; // 👈 SAVE TEXT HERE
    },
  );

  // Wait until speech stops
  while (speech.isListening) {
    await Future.delayed(const Duration(milliseconds: 200));
  }

  return finalText.trim();
}
 
 
 
 
  Future<List<dynamic>> getCachedDailyQuestions( String topic) async {
    final prefs = await SharedPreferences.getInstance();
    final today = DateTime.now().toString().substring(0, 10);

    /// 🗂️ Check existing data
    final savedDate = prefs.getString("daily_date");
    final savedQuestions = prefs.getString("daily_questions");

    /// 🎯 Same day? return old questions
    if (savedDate == today && savedQuestions != null) {
      return jsonDecode(savedQuestions);
    }

    /// 👇 Else fetch new questions
    final fresh = await getDailyQuestions(topic: topic);

    /// 💾 Save new questions
    prefs.setString("daily_date", today);
    prefs.setString("daily_questions", jsonEncode(fresh));

    return fresh;
  }




  /// 📚 Get Daily Questions (AI Generated - follows selected language)
  Future<List<dynamic>> getDailyQuestions({String? topic }) async {
    // ⚠️ Your key

    try {
      final prefs = await SharedPreferences.getInstance();
      final selectedLangCode =
          prefs.getString('selected_language_code')?.toLowerCase() ?? 'en';

      /// 🗣️ Give language instruction
      final String languageInstruction =
          _getLanguageInstruction(selectedLangCode);

      final response = await http.post(
        Uri.parse(_apiUrl),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ${OpenAIConfig.apiKey}',
        },
        body: jsonEncode({
          "model": "gpt-4.1-mini",
          "messages": [
            {
            "role": "system",
            "content": "$languageInstruction Generate quiz content only. Always generate questions, options, answers and explanations in this same language. Output only valid JSON array."
          },
          {
            "role": "user",
            "content":
                "Generate 5 MCQ questions for topic '$topic'. Format strictly like: [{\"question\":\"\",\"options\":[\"\",\"\",\"\",\"\"],\"answer\":\"\",\"explanation\":\"\"}]. Answer and explanation should be in same language as question."
          }
          ],
          "max_tokens": 600
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final content = data['choices'][0]['message']['content'];

        /// 🔐 Fix if AI returns ```json .... ```
        final cleaned = content
            .replaceAll("```json", "")
            .replaceAll("```", "")
            .trim();
            debugPrint("🧠 Daily Questions: $cleaned");

        return jsonDecode(cleaned);
      } else {
        return [];
      }
    } catch (e) {
      debugPrint("❌ Daily Question Error: $e");
      return [];
    }
  }






 /// Fetch daily grammar lesson only
  Future<Map<String, dynamic>> getDailyGrammarLesson() async {
    final prefs = await SharedPreferences.getInstance();
    final selectedLangCode =
        prefs.getString('selected_language_code')?.toLowerCase() ?? 'en';
    final String languageInstruction = _getLanguageInstruction(selectedLangCode);

    try {
      final prompt = """
You are an English tutor AI for beginners.

Generate **one short, simple grammar lesson** suitable for beginners. 
Keep it clear, concise, and beginner-friendly.

Respond **ONLY in JSON format** like this:
{
  "lesson": "Short grammar explanation here."
}
""";

      final res = await http.post(
        Uri.parse(_apiUrl),
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer ${OpenAIConfig.apiKey}",
        },
        body: jsonEncode({
          "model": "gpt-4.1-mini",
          "messages": [
            {"role": "system", "content": languageInstruction},
            {"role": "user", "content": prompt}
          ],
          "max_tokens": 150
        }),
      );

      if (res.statusCode == 200) {
        String aiText = jsonDecode(res.body)["choices"][0]["message"]["content"];
        aiText = aiText.replaceAll("```json", "").replaceAll("```", "").trim();

        final startIndex = aiText.indexOf('{');
        final endIndex = aiText.lastIndexOf('}');
        if (startIndex != -1 && endIndex != -1) {
          aiText = aiText.substring(startIndex, endIndex + 1);
        }

        debugPrint("🧠 Daily Grammar Lesson: $aiText");
        return jsonDecode(aiText);
      } else {
        debugPrint("❌ Failed to fetch lesson: ${res.statusCode}");
        return {"error": "Server Error ${res.statusCode}"};
      }
    } catch (e) {
      debugPrint("⚠️ Error: $e");
      return {"error": e.toString()};
    }
  }

 


// 📚 Get Daily Sentence Formation Question
Future<Map<String, dynamic>> getDailySentenceFormation() async {
  final prefs = await SharedPreferences.getInstance();
  final selectedLangCode = prefs.getString('selected_language_code')?.toLowerCase() ?? 'en';
  final String languageInstruction = _getLanguageInstruction(selectedLangCode);

  try {
    final response = await http.post(
      Uri.parse(_apiUrl),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ${OpenAIConfig.apiKey}',
      },
      body: jsonEncode({
        "model": "gpt-4.1-mini",  // 👈 Safe, cheap, fast model
        "messages": [
          {
            "role": "system",
            "content": "$languageInstruction Create ONE sentence for teaching English sentence formation. Give JSON only."
          },
          {
            "role": "user",
            "content": "Make a grammatically correct sentence. Split it into shuffled words. Format MUST be exactly like:\n\n{\"sentence\":\"\",\"words\":[\"\",\"\",\"\"],\"answer\":[\"\",\"\",\"\"],\"explanation\":\"\"}"
          }
        ],
        "max_tokens": 200
      }),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      String content = data['choices'][0]['message']['content'] ?? "";

      content = content.replaceAll("```json", "")
                       .replaceAll("```", "")
                       .trim();
      debugPrint("🧠 Sentence Formation: $content");

      final startIndex = content.indexOf('{');
      final endIndex = content.lastIndexOf('}');
      if (startIndex != -1 && endIndex != -1) {
        content = content.substring(startIndex, endIndex + 1);
      }

      debugPrint("🧠 Sentence Formation: $content");
      return jsonDecode(content);
    } else {
      debugPrint("❌ Failed to fetch question: ${response.statusCode}");
      return {};
    }
  } catch (e) {
    debugPrint("⚠️ Error: $e");
    return {};
  }
}



 // Fetch Fill in the blanks question
  Future<Map<String, dynamic>> getFillQuestion(String topic) async {
    try {
      final res = await http.post(
        Uri.parse(_apiUrl),
        headers: {
          "Content-Type": "application/json",
        'Authorization': 'Bearer ${OpenAIConfig.apiKey}',
        },
        body: jsonEncode({
          "model": "gpt-4.1-mini",       // Model
          "messages": [
            {
              "role": "user",
              "content":
                  "Give 1 Fill-in-the-blank grammar question (JSON). Example Key: {question:'___ is a boy.', wordList:['He','She','It'], answer:'He'} Topic: $topic"
            }
          ]
        }),
      );

      if (res.statusCode == 200) {
        final result = jsonDecode(res.body);
        final String aiText = result["choices"][0]["message"]["content"];
                debugPrint("🧠 Fill Question: $aiText");

        return jsonDecode(aiText); // Convert String to Map
      } else {
        return {"error": "Server Error ${res.statusCode}"};
      }
    } catch (e) {
      return {"error": e.toString()};
    }
  }



// Fetch Idiom Phrase Explanation
Future<Map<String, dynamic>> getIdiomPhrase(String phrase) async {
  try {
    final res = await http.post(
      Uri.parse(_apiUrl),
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer ${OpenAIConfig.apiKey}",
      },
      body: jsonEncode({
        "model": "gpt-4.1-mini",  // Same model style
        "messages": [
          {
            "role": "user",
            "content": """
Give 1 idiom or phrase info in JSON format.
Example Keys:
{
  "idiom": "Break the ice",
  "meaning": "To start a conversation and reduce tension.",
  "example": "Riya cracked a joke to break the ice on her first day.",
  "explanation": "Used to reduce nervousness and make people feel comfortable."
}
Phrase: $phrase
"""
          }
        ]
      }),
    );

    if (res.statusCode == 200) {
      final result = jsonDecode(res.body);
      final String aiText = result["choices"][0]["message"]["content"];
      debugPrint("🧠 Idiom Response: $aiText");
String cleanedText = aiText
    .replaceAll(RegExp(r"```json"), "")
    .replaceAll(RegExp(r"```"), "")
    .trim();
      return jsonDecode(cleanedText); // Convert AI text -> JSON
    } else {
      return {"error": "Server Error ${res.statusCode}"};
    }
  } catch (e) {
    return {"error": e.toString()};
  }
}





/// Fetch vocabulary words from OpenAI
  Future<List<String>> getVocabulary() async {
    try {
      final res = await http.post(
        Uri.parse(_apiUrl),
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer ${OpenAIConfig.apiKey}",
        },
        body: jsonEncode({
          "model": "gpt-4.1-mini",
          "messages": [
            {
              "role": "user",
              "content": """
Give 10 simple English vocabulary words in JSON array format like:
["word1", "word2", "word3", ..., "word10"]
"""
            }
          ],
          "temperature": 0.5,
          "max_tokens": 250
        }),
      );

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        String aiText = data["choices"][0]["message"]["content"];

        // Remove code block markdown if present
        String cleanedText = aiText
            .replaceAll(RegExp(r"```json"), "")
            .replaceAll(RegExp(r"```"), "")
            .trim();

        final List<dynamic> list = jsonDecode(cleanedText);
        return list.map((e) => e.toString()).toList();
      } else {
        return [];
      }
    } catch (e) {
      return [];
    }
  }

}
