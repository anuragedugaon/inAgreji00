import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../../config/openai_config.dart';

class DailyGrammarService {
  final String _apiUrl = "https://api.openai.com/v1/chat/completions";

  /// 🔹 Get daily lesson + 2 questions (word formation + fill-in-the-blank)
  Future<Map<String, dynamic>> getDailyLessonWithQuestions() async {
    final prefs = await SharedPreferences.getInstance();
    final selectedLangCode =
        prefs.getString('selected_language_code')?.toLowerCase() ?? 'en';
    final String languageInstruction = _getLanguageInstruction(selectedLangCode);

    try {
      final prompt = """
You are an English tutor AI for beginners.

1️⃣ Generate **one short grammar lesson** suitable for beginners.
2️⃣ From this lesson, create **two practice questions**:
   - Question 1: Word formation / sentence formation (shuffle words)
   - Question 2: Fill-in-the-blank question

Respond **ONLY in JSON format** like this:

{
  "lesson": "Short grammar explanation here.",
  "question1": {
    "type": "word_formation",
    "sentence": "He goes to the market.",
    "words": ["goes","He","to","market","the"],
    "answer": ["He","goes","to","the","market"],
    "explanation": "Arrange the words in correct order to form a proper sentence."
  },
  "question2": {
    "type": "fill_in_blank",
    "question": "He ___ to school every day.",
    "wordList": ["go","goes","going"],
    "answer": "goes"
  }
}
""";

      final res = await http.post(
        Uri.parse(_apiUrl),
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer ${OpenAIConfig.apiKey}",
        },
        body: jsonEncode({
          "model": "gpt-4.1-mini",
          "messages": [
            {"role": "system", "content": languageInstruction},
            {"role": "user", "content": prompt}
          ],
          "max_tokens": 500
        }),
      );

      if (res.statusCode == 200) {
        String aiText = jsonDecode(res.body)["choices"][0]["message"]["content"];
        aiText = aiText.replaceAll("```json", "").replaceAll("```", "").trim();

        final startIndex = aiText.indexOf('{');
        final endIndex = aiText.lastIndexOf('}');
        if (startIndex != -1 && endIndex != -1) {
          aiText = aiText.substring(startIndex, endIndex + 1);
        }

        debugPrint("🧠 Daily Lesson + Questions: $aiText");
        return jsonDecode(aiText);
      } else {
        debugPrint("❌ Failed to fetch lesson/questions: ${res.statusCode}");
        return {"error": "Server Error ${res.statusCode}"};
      }
    } catch (e) {
      debugPrint("⚠️ Error: $e");
      return {"error": e.toString()};
    }
  }

  /// 🔹 Optional: Instruction based on app language
  String _getLanguageInstruction(String langCode) {
    switch (langCode) {
      case "hi":
        return "You are an English tutor AI. Explain English in Hindi.";
      default:
        return "You are an English tutor AI. Explain English in simple English.";
    }
  }
}
