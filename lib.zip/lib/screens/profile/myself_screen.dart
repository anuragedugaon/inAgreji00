import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'dart:async';
import 'package:inangreji_flutter/screens/ai_teacher/ai_service.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../provider/app_provider.dart';

class MyselfScreen extends StatefulWidget {
  const MyselfScreen({Key? key}) : super(key: key);

  @override
  State<MyselfScreen> createState() => _MyselfScreenState();
}

class _MyselfScreenState extends State<MyselfScreen> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _ageController = TextEditingController();
  final AIService _aiService = AIService();

  List<String> _cities = [];
  bool _isFetchingCities = true;
  String? _selectedCity;

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _fetchCities();
      _startSpeakingInstruction();
    });
  }

  /// 🧠 Speak localized instruction
  Future<void> _startSpeakingInstruction() async {
    await Future.delayed(const Duration(milliseconds: 200));
    final appProvider = Provider.of<AppProvider>(context, listen: false);
    final text = appProvider.translate("about_yourself") == "about_yourself"
        ? "Tell us about yourself. Please enter your name, age, and select your city."
        : appProvider.translate("about_yourself");
    unawaited(_aiService.speakText(text));
  }

  /// 🏙️ Fetch Cities API
  Future<void> _fetchCities() async {
    try {
      final appProvider = Provider.of<AppProvider>(context, listen: false);
      if (mounted) setState(() => _isFetchingCities = true);
      final cityList = await appProvider.getCities();

      if (mounted) {
        setState(() {
          _cities = cityList
              .map<String>((e) => e['name']?.toString() ?? 'Unknown')
              .toList();
          _isFetchingCities = false;
        });
      }

      debugPrint("✅ Cities loaded (${_cities.length})");
    } catch (e) {
      debugPrint("❌ Error loading cities: $e");
      if (mounted) setState(() => _isFetchingCities = false);
    }
  }

  /// 🎤 Replay instruction
  void _replayInstruction() {
    _aiService.stopSpeaking();
    _startSpeakingInstruction();
  }

  /// ▶️ Handle Continue
  Future<void> _handleContinue() async {
    final appProvider = Provider.of<AppProvider>(context, listen: false);

    if (_nameController.text.isNotEmpty &&
        _ageController.text.isNotEmpty &&
        _selectedCity != null) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('user_city', _selectedCity!);

      final successMsg =
          appProvider.translate("lets_continue") == "lets_continue"
              ? "Great! Let's continue."
              : appProvider.translate("lets_continue");

      await _aiService.speakText(
        successMsg,
        onComplete: () {
          Navigator.pushReplacementNamed(context, '/where');
        },
      );
    } else {
      final warnMsg =
          appProvider.translate("fill_all_fields") == "fill_all_fields"
              ? "Please fill all fields before continuing."
              : appProvider.translate("fill_all_fields");

      _aiService.speakText(warnMsg);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(warnMsg)),
      );
    }
  }

  @override
  void deactivate() {
    _aiService.stopSpeaking();
    super.deactivate();
  }

  @override
  void dispose() {
    _aiService.dispose();
    _nameController.dispose();
    _ageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final appProvider = Provider.of<AppProvider>(context); // listen for locale

    return WillPopScope(
      onWillPop: () async {
        // 🡒 Navigate back to '/choose' instead of popping
        Navigator.pushReplacementNamed(context, '/level');
        return false; // prevent default pop
      },
      child: Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          actions: [
            IconButton(
              onPressed: _replayInstruction,
              icon: const Icon(Icons.mic, color: Colors.cyan, size: 28),
              tooltip: 'Replay Voice',
            ),
          ],
        ),
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const SizedBox(height: 20),

                /// Title (translated)
                Text(
                  appProvider.translate("about_you_title") == "about_you_title"
                      ? "Tell us about\nyourself"
                      : appProvider.translate("about_you_title"),
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.bold,
                    color: Colors.cyan,
                  ),
                ),
                const SizedBox(height: 40),

                /// Name field
                _buildTextField(
                  controller: _nameController,
                  label: appProvider.translate("name") == "name"
                      ? "Name"
                      : appProvider.translate("name"),
                  hint: appProvider.translate("enter_name") == "enter_name"
                      ? "Enter your name"
                      : appProvider.translate("enter_name"),
                  keyboardType: TextInputType.name,
                ),
                const SizedBox(height: 20),

                /// Age field
                _buildTextField(
                  controller: _ageController,
                  label: appProvider.translate("age") == "age"
                      ? "Age"
                      : appProvider.translate("age"),
                  hint: appProvider.translate("enter_age") == "enter_age"
                      ? "Enter your age"
                      : appProvider.translate("enter_age"),
                  keyboardType: TextInputType.number,
                ),
                const SizedBox(height: 20),

                /// City Dropdown (translated)
                _buildCityDropdown(appProvider),

                const Spacer(),

                /// Continue Button
                GestureDetector(
                  onTap: _handleContinue,
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(30),
                      gradient: const LinearGradient(
                        colors: [Colors.deepOrange, Colors.orange],
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.orange.withOpacity(0.6),
                          blurRadius: 12,
                          spreadRadius: 1,
                        ),
                      ],
                    ),
                    child: Center(
                      child: Text(
                        appProvider.translate("continue") == "continue"
                            ? "Continue"
                            : appProvider.translate("continue"),
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 30),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// 🏙️ City Dropdown
  Widget _buildCityDropdown(AppProvider appProvider) {
    if (_isFetchingCities) {
      return Container(
        height: 55,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.cyan),
          color: Colors.black26,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const SizedBox(
              width: 20,
              height: 20,
              child: CircularProgressIndicator(
                color: Colors.cyan,
                strokeWidth: 2,
              ),
            ),
            const SizedBox(width: 12),
            Text(
              appProvider.translate("loading_cities") == "loading_cities"
                  ? "Loading cities..."
                  : appProvider.translate("loading_cities"),
              style: const TextStyle(color: Colors.white70, fontSize: 16),
            ),
          ],
        ),
      );
    }

    if (_cities.isEmpty) {
      return Container(
        height: 55,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.redAccent),
        ),
        child: Text(
          appProvider.translate("no_cities") == "no_cities"
              ? "No cities available"
              : appProvider.translate("no_cities"),
          style: const TextStyle(color: Colors.redAccent, fontSize: 16),
        ),
      );
    }

    return Container(
      height: 55,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.cyan),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          isExpanded: true,
          dropdownColor: Colors.black87,
          value: _selectedCity,
          hint: Text(
            appProvider.translate("select_city") == "select_city"
                ? "Select City"
                : appProvider.translate("select_city"),
            style: const TextStyle(color: Colors.grey),
          ),
          items: _cities.map((city) {
            return DropdownMenuItem(
              value: city,
              child: Text(
                city,
                style: const TextStyle(color: Colors.white),
              ),
            );
          }).toList(),
          onChanged: (value) {
            setState(() {
              _selectedCity = value;
            });
          },
        ),
      ),
    );
  }

  /// 🧾 Text Field Builder
  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required TextInputType keyboardType,
  }) {
    return TextField(
      controller: controller,
      keyboardType: keyboardType,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(color: Colors.cyan),
        hintText: hint,
        hintStyle: const TextStyle(color: Colors.grey),
        enabledBorder: OutlineInputBorder(
          borderSide: const BorderSide(color: Colors.cyan),
          borderRadius: BorderRadius.circular(12),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: const BorderSide(color: Colors.cyan, width: 2),
          borderRadius: BorderRadius.circular(12),
        ),
      ),
    );
  }
}
