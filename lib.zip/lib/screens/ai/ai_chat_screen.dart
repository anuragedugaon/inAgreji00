import 'package:flutter/material.dart';

import '../ai_teacher/ai_service.dart';
import 'voice_chat_screen.dart';

class AiChatScreen extends StatefulWidget {
  const AiChatScreen({super.key});

  @override
  State<AiChatScreen> createState() => _AiChatScreenState();
}

class _AiChatScreenState extends State<AiChatScreen> {
  final AIService ai = AIService(); // 🤖 AI Instance
  final TextEditingController _msgController = TextEditingController();
  bool isThinking = false; // ⏳ Loader while waiting
  bool isListening = false;
  String lastUserText = "";
  String lastAiText = "";
  ChatSession chatSession = ChatSession();

  void sendMessage() async {
    String text = _msgController.text.trim();
    if (text.isEmpty) return;

    setState(() {
      chatSession.messages.add({"text": text, "isUser": true});
      isThinking = true;
    });
    _msgController.clear();

    // 👉 Wait for AI reply
    String aiReply = await ai.getAnswer(text);

    setState(() {
      chatSession.messages.add({"text": aiReply, "isUser": false});
      isThinking = false;
    });

    // 🔊 Speak the reply
    ai.speakText(aiReply);
  }

  @override
  Widget build(BuildContext context) {
    const Color backgroundColor = Colors.black;
    const Color titleColor = Colors.cyanAccent;
    const Color bubbleColor = Color(0xFF1C1C1E);
    const Color accentColor = Colors.cyanAccent;

    return Scaffold(
      backgroundColor: backgroundColor,
      body: SafeArea(
        child: Column(
          children: [
            // 🔙 Top Bar
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              child: Row(
                children: [
                  IconButton(
                      onPressed: () => Navigator.pop(context),
                      icon:
                          const Icon(Icons.arrow_back_ios, color: accentColor)),
                  const Spacer(),
                  const Text("Ask me anything in English",
                      style: TextStyle(
                          color: titleColor,
                          fontSize: 16,
                          fontWeight: FontWeight.bold)),
                  const Spacer(flex: 2),
                ],
              ),
            ),

            // 🤖 Avatar + Name
            Container(
              width: 160,
              height: 160,
              decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: bubbleColor,
                  border: Border.all(color: accentColor, width: 2)),
              child: ClipOval(
                  child:
                      Image.asset('assets/images/ai.png', fit: BoxFit.cover)),
            ),
            const SizedBox(height: 10),
            const Text("SIA",
                style: TextStyle(color: Colors.white70, fontSize: 14)),
            const SizedBox(height: 25),

            // 💬 Chat List
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                itemCount: chatSession.messages.length + (isThinking ? 1 : 0),
                itemBuilder: (context, index) {
                  if (index == chatSession.messages.length && isThinking) {
                    return _typingIndicator(); // ⏳ Loader
                  }

                  final msg = chatSession.messages[index];
                  bool isUser = msg["isUser"];

                  return Align(
                    alignment:
                        isUser ? Alignment.centerRight : Alignment.centerLeft,
                    child: Container(
                      margin: const EdgeInsets.symmetric(vertical: 6),
                      padding: const EdgeInsets.symmetric(
                          vertical: 12, horizontal: 16),
                      decoration: BoxDecoration(
                        color: bubbleColor,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: accentColor, width: 1.2),
                      ),
                      child: Text(
                        msg["text"],
                        style:
                            const TextStyle(color: Colors.white, fontSize: 16),
                      ),
                    ),
                  );
                },
              ),
            ),

            // 📝 Input + Send + Mic
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                    color: bubbleColor,
                    borderRadius: BorderRadius.circular(30),
                    border: Border.all(color: accentColor, width: 1.2)),
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _msgController,
                        style: const TextStyle(color: Colors.white),
                        decoration: const InputDecoration(
                            hintText: "Type a message...",
                            hintStyle: TextStyle(color: Colors.white54),
                            border: InputBorder.none),
                      ),
                    ),
                    IconButton(
                        onPressed: sendMessage,
                        icon: const Icon(Icons.send, color: accentColor)),
                    IconButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => VoiceChatScreen()),
                          );
                          // startListening();
                        }, // 🎤 Mic (will add next)
                        icon: const Icon(Icons.mic, color: accentColor)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ⏳ Typing Animation
  Widget _typingIndicator() {
    return Align(
      alignment: Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 6),
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
        decoration: BoxDecoration(
            color: Colors.white10,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Colors.cyanAccent, width: 1)),
        child: const Text("SIA is typing...",
            style: TextStyle(color: Colors.white70)),
      ),
    );
  }

  // 🎤 Start Listening (User Voice)
  Future<void> startListening() async {
    setState(() => isListening = true);

    final text = await ai.listenVoice();
    if (text.trim().isNotEmpty) {
      processVoice(text);
    }
  }

  Future<void> processVoice(String text) async {
    setState(() {
      lastUserText = text;
      isListening = false;
    });

    if (text.isEmpty) return;

    setState(() {
      chatSession.messages.add({"text": text, "isUser": true});
      isThinking = true;
    });

    // 👉 Wait for AI reply
    String aiReply = await ai.getAnswer(text);

    setState(() {
      chatSession.messages.add({"text": aiReply, "isUser": false});
      isThinking = false;
    });

    // 🔊 Speak the reply
    ai.speakText(aiReply); // 🔥 FIXED (this keeps auto mic working)
  }




}

class ChatSession {
  List<Map<String, dynamic>> messages = [
    {"text": "Hello! How can I assist you today?", "isUser": false},
  ];
}
