import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import '../../services/video_player.dart';
import '../ai_teacher/ai_service.dart';
import 'ai_chat_screen.dart';

/// --- Color constants ---
class AppColors {
  static const Color backgroundDark = Colors.black;
  static const Color primaryBlue = Color(0xFF00BFFF); // Neon blue
  static const Color textWhite = Colors.white;
  static const Color subtitleColor = Colors.white70;
}
class VoiceChatScreen extends StatefulWidget {
  const VoiceChatScreen({super.key});

  @override
  State<VoiceChatScreen> createState() => _VoiceChatScreenState();
}

class _VoiceChatScreenState extends State<VoiceChatScreen> with SingleTickerProviderStateMixin  {
  final AIService _ai = AIService();
  final FlutterTts tts = FlutterTts();

  bool isListening = false;
  String lastUserText = "";
  String lastAiText = "";
  ChatSession chatSession = ChatSession();
  late AnimationController _glowController;
  bool _isSpeaking = false;
  @override
  void initState() {
    super.initState();

    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
      lowerBound: 0.2,
      upperBound: 1.0,
    )..repeat(reverse: true);
    // 🔊 जब AI बोलना खत्म करे → Mic चालू
    tts.setCompletionHandler(() {
      startListening();
    });

    // 🎉 Page open होते ही AI Welcome बोले
    Future.delayed(const Duration(milliseconds: 600), () async {
      await greetUser();
    });
  }

  // 👋 AI का पहला Welcome Message + Mic Auto Start
  Future<void> greetUser() async {
    const welcome = "Hi, I am your AI teacher. Ask me anything.";
    setState(() => lastAiText = welcome);

    chatSession.messages.add({"role": "assistant", "text": welcome});

    await tts.speak(welcome); // बोलने के बाद mic चालू होगा (auto)
  }

  // 🎤 Start Listening (User Voice)
  Future<void> startListening() async {
    setState(() => isListening = true);

    final text = await _ai.listenVoice();
    if (text.trim().isNotEmpty) {
      processVoice(text);
    }
  }



Future<void> processVoice(String text) async {
  setState(() {
    lastUserText = text;
    isListening = false;
  });

  chatSession.messages.add({"role": "user", "text": text});
  debugPrint('User said: $text');

  final reply = await _ai.getAnswer(text);
  setState(() => lastAiText = reply);
  debugPrint('AI Reply: $reply');

  chatSession.messages.add({"role": "assistant", "text": reply});

  await _ai.speakText(reply);  // 🔥 FIXED (this keeps auto mic working)
}


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text("Voice Chat"),
        backgroundColor: Colors.black,
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // Text(lastUserText, style: const TextStyle(color: Colors.white)),
          // const SizedBox(height: 10),
          // Text(lastAiText, style: const TextStyle(color: Colors.cyanAccent)),

            /// --- Animated Teacher (Lottie) ---
                AnimatedBuilder(
                  animation: _glowController,
                  builder: (context, child) {
                    final glow = _isSpeaking ? _glowController.value * 40 : 0.0;
                    final fadeOpacity = _glowController.value;

                    return Stack(
                      alignment: Alignment.center,
                      children: [
                        // 🌌 Faded glow background
                        AnimatedOpacity(
                          duration: const Duration(milliseconds: 500),
                          opacity: _isSpeaking ? fadeOpacity : 0.4,
                          child: Container(
                            height: 280,
                            width: 280,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: RadialGradient(
                                colors: [
                                  AppColors.primaryBlue.withOpacity(0.25),
                                  Colors.transparent,
                                ],
                                stops: const [0.3, 1.0],
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: AppColors.primaryBlue
                                      .withOpacity(0.5 * fadeOpacity),
                                  blurRadius: glow,
                                  spreadRadius: glow / 4,
                                ),
                              ],
                            ),
                          ),
                        ),

                        // 🧠 Teacher animation
                        TeacherAnimation(isSpeaking: _isSpeaking),
// SizedBox(
//   height: 300,
//   width: 220,
//   child: Image.asset(
//     'assets/video/316338_small.gif',
//     fit: BoxFit.contain,
//   ),
// ),

                        // SizedBox(
                        //   height: 220,
                        //   width: 220,
                        //   child: Lottie.asset(
                        //     'assets/animations/human_ani.json',
                        //     repeat: _isSpeaking,
                        //     animate: true,
                        //     // fit: BoxFit.contain,
                        //   ),
                        // ),
                      ],
                    );
                  },
                ),

             
             
          const SizedBox(height: 20),

          GestureDetector(
            onTap: () => startListening(), // पहले manual tap if needed
            child: Icon(
    isListening ? Icons.mic : Icons.mic_off,
              color: Colors.white,
              size: 80,
            ),
          ),
        ],
      ),
    );
  }
}
