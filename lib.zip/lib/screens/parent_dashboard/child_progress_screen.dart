import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:inangreji_flutter/provider/app_provider.dart';

class ChildProgressScreen extends StatefulWidget {
  const ChildProgressScreen({super.key});

  @override
  State<ChildProgressScreen> createState() => _ChildProgressScreenState();
}

class _ChildProgressScreenState extends State<ChildProgressScreen> {
  static const Color kBackgroundStart = Color(0xFF000000);
  static const Color kBackgroundEnd = Color(0xFF0047AB);
  static const Color kAccent = Colors.cyanAccent;

  bool isLoading = true;
  List<dynamic> lessons = [];
  List<dynamic> goals = [];
  List<dynamic> achievements = [];

  @override
  void initState() {
    super.initState();
    _loadProgressData();
  }

  Future<void> _loadProgressData() async {
    final provider = Provider.of<AppProvider>(context, listen: false);

    final fetchedLessons = await provider.getUserLessons();
    final fetchedGoals = await provider.getGoals();
    final fetchedAchievements = await provider.getAchievements();

    setState(() {
      lessons = fetchedLessons;
      goals = fetchedGoals;
      achievements = fetchedAchievements;
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [kBackgroundStart, kBackgroundEnd],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          centerTitle: true,
          title: const Text(
            "Child Progress",
            style: TextStyle(
              color: kAccent,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        body: isLoading
            ? const Center(
                child: CircularProgressIndicator(color: kAccent),
              )
            : RefreshIndicator(
                onRefresh: _loadProgressData,
                color: kAccent,
                backgroundColor: Colors.black,
                child: ListView(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  children: [
                    const SizedBox(height: 12),

                    // 🔹 Summary Card
                    _buildSummaryCard(),

                    const SizedBox(height: 20),

                    // 🔹 Daily / Weekly Reports
                    _buildReportSection(),

                    const SizedBox(height: 20),

                    // 🔹 Achievements Section
                    _buildAchievementsSection(),

                    const SizedBox(height: 20),
                  ],
                ),
              ),
      ),
    );
  }

  /// 🧮 Summary Section
  Widget _buildSummaryCard() {
    int totalLessons = lessons.length;
    int totalGoals = goals.length;
    int totalAchievements = achievements.length;

    return Container(
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: kAccent.withOpacity(0.3)),
      ),
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          const Text(
            "Performance Summary",
            style: TextStyle(
              color: kAccent,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _summaryItem(Icons.book_rounded, "Lessons", totalLessons),
              _summaryItem(Icons.flag_rounded, "Goals", totalGoals),
              _summaryItem(Icons.emoji_events_rounded, "Achievements",
                  totalAchievements),
            ],
          ),
        ],
      ),
    );
  }

  Widget _summaryItem(IconData icon, String label, int value) {
    return Column(
      children: [
        Icon(icon, color: kAccent, size: 32),
        const SizedBox(height: 6),
        Text(
          value.toString(),
          style: const TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        Text(
          label,
          style: const TextStyle(color: Colors.white70, fontSize: 14),
        ),
      ],
    );
  }

  /// 📆 Reports Section
  Widget _buildReportSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "Weekly Report",
          style: TextStyle(
            color: kAccent,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: kAccent.withOpacity(0.3)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: const [
              Text("🗓️ Lessons Completed: 5/10",
                  style: TextStyle(color: Colors.white)),
              SizedBox(height: 6),
              Text("📖 Practice Streak: 7 days",
                  style: TextStyle(color: Colors.white)),
              SizedBox(height: 6),
              Text("🏅 Accuracy: 85%", style: TextStyle(color: Colors.white)),
            ],
          ),
        ),
      ],
    );
  }

  /// 🏆 Achievements Section
  Widget _buildAchievementsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "Achievements",
          style: TextStyle(
            color: kAccent,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 12),
        achievements.isEmpty
            ? const Text(
                "No achievements yet 🎯",
                style: TextStyle(color: Colors.white70),
              )
            : Column(
                children: achievements.map((ach) {
                  return Container(
                    margin: const EdgeInsets.only(bottom: 12),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: kAccent.withOpacity(0.4)),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.star, color: Colors.amber, size: 32),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                ach['title'] ?? 'Achievement',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                ach['description'] ?? '',
                                style: const TextStyle(
                                  color: Colors.white70,
                                  fontSize: 13,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const Icon(Icons.arrow_forward_ios,
                            color: Colors.white38, size: 16),
                      ],
                    ),
                  );
                }).toList(),
              ),
      ],
    );
  }
}
