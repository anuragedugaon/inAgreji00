// go_premium_screen.dart
import 'package:flutter/material.dart';

import '../../routes/app_routes.dart';

/// Go Premium screen for Inangreji
/// - Black background
/// - Cyan bordered cards & buttons with subtle cyan glow
/// - Large "Go Premium" hero card + feature list + "See Plans" button
class GoPremiumScreen extends StatelessWidget {
  const GoPremiumScreen({super.key});

  // Named colors (avoid raw literals throughout the code)
  static const Color kBackground = Colors.black;
  static const Color kBorder = Colors.cyanAccent;
  static const Color kGlow = Color(0xFF80FFFF);
  static const Color kCardFill = Color(0xFF0F0F10); // subtle card fill
  static const Color kText = Colors.white;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBackground,
      appBar: AppBar(
        backgroundColor: kBackground,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: kBorder),
          onPressed: () => Navigator.maybePop(context),
        ),
        title: const Text(
          'Go Premium',
          style: TextStyle(color: kBorder, fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 26),
          child: Column(
            children: [
              // Big hero "Go Premium" card
              _heroCard(context),

              const SizedBox(height: 28),

              // Feature list (icon + text) in compact cards
              _featureCardRow(Icons.check_circle_outline, "Unlimited Practice"),
              const SizedBox(height: 12),
              _featureCardRow(Icons.rate_review_outlined, "Detailed Feedback"),
              const SizedBox(height: 12),
              _featureCardRow(Icons.block, "No Ads"),

              const Spacer(),

              // "See Plans" CTA button
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    // navigate to plans (replace with your route)
                    // Navigator.pushReplacementNamed(context, AppRoutes.plans);
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.transparent,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                      side: const BorderSide(color: kBorder, width: 1.5),
                    ),
                    elevation: 10,
                    shadowColor: kGlow.withOpacity(0.6),
                  ),
                  child: const Text(
                    "See Plans",
                    style: TextStyle(
                      color: kBorder,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Large top card that visually emphasizes "Go Premium"
  Widget _heroCard(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 22, horizontal: 20),
      decoration: BoxDecoration(
        color: kCardFill,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: kBorder, width: 1.6),
        boxShadow: [
          BoxShadow(
            color: kGlow.withOpacity(0.35),
            blurRadius: 16,
            spreadRadius: 2,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        children: const [
          Text(
            'Go Premium',
            style: TextStyle(
              color: kBorder,
              fontSize: 26,
              fontWeight: FontWeight.bold,
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 8),
          Text(
            'Unlock unlimited practice, personalized feedback\nand an ad-free learning experience.',
            style: TextStyle(color: kText, fontSize: 14, height: 1.4),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  /// A single feature row styled as a card (icon on left, text on right)
  Widget _featureCardRow(IconData icon, String label) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 14),
      decoration: BoxDecoration(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: kBorder, width: 1.2),
        boxShadow: [
          BoxShadow(
            color: kGlow.withOpacity(0.25),
            blurRadius: 8,
            spreadRadius: 1,
          ),
        ],
      ),
      child: Row(
        children: [
          // Icon container (circular)
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.transparent,
              border: Border.all(color: kBorder, width: 1.2),
            ),
            child: Icon(icon, color: kBorder, size: 20),
          ),

          const SizedBox(width: 14),

          // Label
          Expanded(
            child: Text(
              label,
              style: const TextStyle(
                color: kText,
                fontSize: 16,
              ),
            ),
          ),

          // small forward chevron
          const Icon(Icons.arrow_forward_ios, color: kBorder, size: 16),
        ],
      ),
    );
  }
}
