// import 'package:flutter/material.dart';
// import 'package:lottie/lottie.dart';
// import 'package:flutter_tts/flutter_tts.dart';

// import '../../services/video_player.dart';

// class ChooseOptionScreen extends StatefulWidget {
//   const ChooseOptionScreen({super.key});

//   @override
//   State<ChooseOptionScreen> createState() => _ChooseOptionScreenState();
// }

// class _ChooseOptionScreenState extends State<ChooseOptionScreen>
//     with SingleTickerProviderStateMixin {
//   String? selectedOption;
//   final String correctAnswer = "Please get the menu!";

//   final List<String> options = ["the", "get", "menu!", "Please"];
//   final List<String> selectedWords = [];

//   late AnimationController _controller;
//   late Animation<Color?> _gradient1;
//   late Animation<Color?> _gradient2;

//   final FlutterTts _flutterTts = FlutterTts();
//   bool _isSpeaking = false; // controls which animation to show

//   @override
//   void initState() {
//     super.initState();

//     // 🎨 Animated gradient background
//     _controller = AnimationController(
//       vsync: this,
//       duration: const Duration(seconds: 5),
//     )..repeat(reverse: true);

//     _gradient1 = ColorTween(
//       begin: Colors.black,
//       end: const Color(0xFF001F3F),
//     ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));

//     _gradient2 = ColorTween(
//       begin: const Color(0xFF00BFFF),
//       end: const Color(0xFF0077FF),
//     ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));

//     // 🔊 Make teacher speak after screen loads
//     WidgetsBinding.instance.addPostFrameCallback((_) {
//       _speakQuestion();
//     });
//   }

//   Future<void> _speakQuestion() async {
//     await _flutterTts.setLanguage("en-IN");
//     await _flutterTts.setPitch(1.0);
//     await _flutterTts.setSpeechRate(0.55); // 👈 slower, clear voice
//     await _flutterTts.setVolume(1.0);

//     setState(() => _isSpeaking = true);
//     await _flutterTts.speak("Please get the menu!");
//     _flutterTts.setCompletionHandler(() {
//       setState(() => _isSpeaking = false);
//     });
//   }

//   @override
//   void dispose() {
//     _controller.dispose();
//     _flutterTts.stop();
//     super.dispose();
//   }

//   void _onWordTap(String word) {
//     setState(() {
//       if (selectedWords.contains(word)) {
//         selectedWords.remove(word);
//       } else {
//         selectedWords.add(word);
//       }
//     });
//   }

//   void _onCheck() {
//     final formedSentence = selectedWords.join(" ");
//     if (formedSentence == correctAnswer) {
//       ScaffoldMessenger.of(context).showSnackBar(
//         const SnackBar(
//           content: Text("✅ Correct!"),
//           backgroundColor: Colors.green,
//         ),
//       );
//       Future.delayed(const Duration(seconds: 1), () {
//         Navigator.pushReplacementNamed(context, '/blank');
//       });
//     } else {
//       ScaffoldMessenger.of(context).showSnackBar(
//         const SnackBar(
//           content: Text("❌ Try again!"),
//           backgroundColor: Colors.redAccent,
//         ),
//       );
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return AnimatedBuilder(
//       animation: _controller,
//       builder: (context, _) {
//         return Scaffold(
//           body: Container(
//             decoration: BoxDecoration(
//               gradient: LinearGradient(
//                 colors: [_gradient1.value!, _gradient2.value!],
//                 begin: Alignment.topLeft,
//                 end: Alignment.bottomRight,
//               ),
//             ),
//             child: SafeArea(
//               child: Padding(
//                 padding:
//                     const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.center,
//                   children: [
//                     // 🔸 Progress bar
//                     Padding(
//                       padding: const EdgeInsets.only(top: 10.0),
//                       child: LinearProgressIndicator(
//                         value: 0.3,
//                         backgroundColor: Colors.white12,
//                         color: Colors.orangeAccent,
//                         minHeight: 4,
//                         borderRadius: BorderRadius.circular(4),
//                       ),
//                     ),

//                     const SizedBox(height: 25),

//                     // 🎧 Instruction text
//                     const Text(
//                       "Listen and arrange.",
//                       style: TextStyle(
//                         color: Colors.cyanAccent,
//                         fontSize: 20,
//                         fontWeight: FontWeight.bold,
//                       ),
//                     ),

//                     const SizedBox(height: 30),

//                     // 👩‍🏫 AI Teacher Animation (dynamic)
//                     // Lottie.asset(
//                     //   _isSpeaking
//                     //       ? 'assets/animations/teacher_speaking.json'
//                     //       : 'assets/animations/teacher_idle.json',
//                     //   height: 150,
//                     //   repeat: true,
//                     // ),
//                         TeacherAnimation(isSpeaking: _isSpeaking),

//                     // 🧩 Selected Words Display Area
//                     Container(
//                       height: 60,
//                       width: double.infinity,
//                       decoration: BoxDecoration(
//                         border: Border.all(
//                           color: Colors.cyanAccent.withOpacity(0.3),
//                           width: 1.2,
//                         ),
//                         borderRadius: BorderRadius.circular(12),
//                       ),
//                       alignment: Alignment.center,
//                       child: Text(
//                         selectedWords.isEmpty ? "" : selectedWords.join(" "),
//                         style: const TextStyle(
//                           color: Colors.white,
//                           fontSize: 18,
//                           fontWeight: FontWeight.w500,
//                         ),
//                       ),
//                     ),

//                     const SizedBox(height: 30),

//                     // 🧱 Word Buttons
//                     Wrap(
//                       alignment: WrapAlignment.center,
//                       spacing: 12,
//                       runSpacing: 12,
//                       children: options
//                           .map((word) => GestureDetector(
//                                 onTap: () => _onWordTap(word),
//                                 child: AnimatedContainer(
//                                   duration: const Duration(milliseconds: 200),
//                                   padding: const EdgeInsets.symmetric(
//                                       horizontal: 18, vertical: 12),
//                                   decoration: BoxDecoration(
//                                     color: selectedWords.contains(word)
//                                         ? Colors.cyanAccent.withOpacity(0.3)
//                                         : Colors.transparent,
//                                     borderRadius: BorderRadius.circular(12),
//                                     border: Border.all(
//                                       color: selectedWords.contains(word)
//                                           ? Colors.cyanAccent
//                                           : Colors.cyanAccent.withOpacity(0.3),
//                                       width: 1.5,
//                                     ),
//                                   ),
//                                   child: Text(
//                                     word,
//                                     style: TextStyle(
//                                       color: selectedWords.contains(word)
//                                           ? Colors.cyanAccent
//                                           : Colors.white,
//                                       fontSize: 16,
//                                       fontWeight: FontWeight.bold,
//                                     ),
//                                   ),
//                                 ),
//                               ))
//                           .toList(),
//                     ),

//                     const Spacer(),

//                     // ✅ Check Button Section
//                     Column(
//                       children: [
//                         Row(
//                           mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                           children: [
//                             ElevatedButton(
//                               onPressed:
//                                   selectedWords.isNotEmpty ? _onCheck : null,
//                               style: ElevatedButton.styleFrom(
//                                 backgroundColor: Colors.transparent,
//                                 padding: const EdgeInsets.symmetric(
//                                     horizontal: 40, vertical: 12),
//                                 shape: RoundedRectangleBorder(
//                                   borderRadius: BorderRadius.circular(12),
//                                   side: const BorderSide(
//                                       color: Colors.cyanAccent, width: 1.5),
//                                 ),
//                                 shadowColor: Colors.cyanAccent.withOpacity(0.6),
//                               ),
//                               child: const Text(
//                                 "CHECK",
//                                 style: TextStyle(
//                                   color: Colors.cyanAccent,
//                                   fontSize: 16,
//                                   fontWeight: FontWeight.bold,
//                                 ),
//                               ),
//                             ),
//                             TextButton(
//                               onPressed: _speakQuestion,
//                               child: const Text(
//                                 "🔁 Listen Again",
//                                 style: TextStyle(
//                                   color: Colors.white,
//                                   fontSize: 15,
//                                   decoration: TextDecoration.underline,
//                                 ),
//                               ),
//                             ),
//                           ],
//                         ),
//                       ],
//                     ),
//                   ],
//                 ),
//               ),
//             ),
//           ),
//         );
//       },
//     );
//   }
// }
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';

import '../../services/video_player.dart';
import '../ai_teacher/ai_service.dart';
import '../ai_teacher/daily_grammer_serv.dart';
import 'lessons/fill_the_blank_screen.dart'; // for TeacherAnimation

class ChooseOptionScreen extends StatefulWidget {
  const ChooseOptionScreen({super.key});

  @override
  State<ChooseOptionScreen> createState() => _ChooseOptionScreenState();
}

class _ChooseOptionScreenState extends State<ChooseOptionScreen>
    with SingleTickerProviderStateMixin {
  List<String> options = [];
  List<String> selectedWords = [];
  List<String> correctAnswer = [];
  String questionText = "Listen and arrange.";
  bool _isSpeaking = false;
  bool _isLoading = true;
  List<int> selectedIndexes = [];
  String? lession;
  bool isPage = false;
  String? q2Question;
  List<String> q2WordList = [];
  String? q2Answer;
  late AnimationController _controller;
  late Animation<Color?> _gradient1;
  late Animation<Color?> _gradient2;

  final FlutterTts _flutterTts = FlutterTts();

  @override
  void initState() {
    super.initState();

    // Animated gradient
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 5),
    )..repeat(reverse: true);

    _gradient1 = ColorTween(begin: Colors.black, end: const Color(0xFF001F3F))
        .animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));
    _gradient2 = ColorTween(
            begin: const Color(0xFF00BFFF), end: const Color(0xFF0077FF))
        .animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _fetchQuestion();
    });
  }

  Future<void> _fetchQuestion() async {
    setState(() => _isLoading = true);
    final service = DailyGrammarService();
    try {
      final result = await service.getDailyLessonWithQuestions();

      if (result.isNotEmpty) {
        setState(() {
          lession = result['lesson'];
          Map<String, dynamic> question1 = result['question1'] ?? {};
          debugPrint("$question1");

          questionText = question1['sentence'] ?? "Listen and arrange.";
          options = List<String>.from(question1['words'] ?? []);
          correctAnswer =
              List<String>.from(result['question1']['answer'] ?? []);

          Map<String, dynamic> question2 = result['question2'] ?? {};
          q2Question = question2['question'] ?? "";
          q2WordList = List<String>.from(question2['wordList'] ?? []);
          q2Answer = question2['answer'] ?? "";
        });
        debugPrint(questionText);

        _speakQuestion(lession ?? "");
      }
    } catch (e) {
      debugPrint("❌ API Error: $e");
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _speakQuestion(String lession) async {
    if (questionText.isEmpty) return;

    await _flutterTts.setLanguage("en-IN");
    await _flutterTts.setPitch(1.0);
    await _flutterTts.setSpeechRate(0.55);
    await _flutterTts.setVolume(1.0);

    setState(() => _isSpeaking = true);
    await _flutterTts.speak(lession);
    _flutterTts.setCompletionHandler(() => setState(() => _isSpeaking = false));
  }

// void _onWordTap(String word) {
//   // Count how many times selectedWords contain this word
//   int count = selectedWords.where((w) => w == word).length;

//   setState(() {
//     if (selectedWords.contains(word)) {
//       selectedWords.remove(word);
//     } else {
//       // allow only ONE selection of duplicate words
//       if (count < 1) {
//         selectedWords.add(word);
//       } else {
//         ScaffoldMessenger.of(context).showSnackBar(
//           const SnackBar(
//             content: Text("⚠️ Word already selected!"),
//             backgroundColor: Colors.orange,
//             duration: Duration(milliseconds: 700),
//           ),
//         );
//       }
//     }
//   });
// }

  void _onWordTap(int index) {
    setState(() {
      if (selectedIndexes.contains(index)) {
        selectedIndexes.remove(index);
      } else {
        selectedIndexes.add(index);
      }
    });
  }

  // void _onCheck() {
  //   final formedSentence = selectedWords.join(" ");
  //   if (formedSentence == correctAnswer) {
  //     ScaffoldMessenger.of(context).showSnackBar(
  //       const SnackBar(
  //         content: Text("✅ Correct!"),
  //         backgroundColor: Colors.green,
  //       ),
  //     );
  //     Future.delayed(const Duration(seconds: 1), () {
  //       Navigator.pushReplacementNamed(context, '/blank');
  //     });
  //   } else {
  //     ScaffoldMessenger.of(context).showSnackBar(
  //       const SnackBar(
  //         content: Text("❌ Try again!"),
  //         backgroundColor: Colors.redAccent,
  //       ),
  //     );
  //   }
  // }

  void _onCheck() {
    // ❗ First: size must match
    if (selectedIndexes.length != correctAnswer.length) {
      _showError();
      return;
    }

    // ❗ Now compare actual words in same order
    bool isCorrect = true;
    for (int i = 0; i < correctAnswer.length; i++) {
      if (options[selectedIndexes[i]] != correctAnswer[i]) {
        isCorrect = false;
        break;
      }
    }

    // Result
    if (isCorrect) {
      _showSuccess();
    } else {
      _showError();
    }
  }

  void _showSuccess() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text("🎉 Great! Correct Sentence!"),
        backgroundColor: Colors.green,
        duration: Duration(seconds: 1),
      ),
    );

    Future.delayed(const Duration(seconds: 1), () {
      Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => FillTheBlankScreen(
              question: q2Question ?? "",
              word: q2WordList,
              answer: q2Answer ?? "",
            ),
          ));
    });
  }

  void _showError() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text("❌ Incorrect! Try again"),
        backgroundColor: Colors.redAccent,
        duration: Duration(seconds: 1),
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    _flutterTts.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(color: Colors.cyanAccent))
          : AnimatedBuilder(
              animation: _controller,
              builder: (context, _) {
                return Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [_gradient1.value!, _gradient2.value!],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                  child: SafeArea(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 10),
                      child: SingleChildScrollView(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            // Progress bar
                            Padding(
                              padding: const EdgeInsets.only(top: 10.0),
                              child: LinearProgressIndicator(
                                value: 0.3,
                                backgroundColor: Colors.white12,
                                color: Colors.orangeAccent,
                                minHeight: 4,
                                borderRadius: BorderRadius.circular(4),
                              ),
                            ),
                            const SizedBox(height: 25),
                            // Instruction text
                            Text(
                              "Listen and arrange.",
                              style: const TextStyle(
                                color: Colors.cyanAccent,
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 30),
                            // Teacher animation
                            TeacherAnimation(isSpeaking: _isSpeaking),
                            isPage ? wordArrange() : grammerSentence(),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
    );
  }

  Widget grammerSentence() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Text(
          lession ?? "", // 👈 FIX
          style: const TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.w500,
          ),
        ),
        // Check & listen again buttons
        const SizedBox(height: 40),

        Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: () {
                    _speakQuestion(questionText ?? "");
                    setState(() {
                      isPage = true;
                    });
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.transparent,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 40, vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                      side: const BorderSide(
                          color: Colors.cyanAccent, width: 1.5),
                    ),
                    shadowColor: Colors.cyanAccent.withOpacity(0.6),
                  ),
                  child: const Text(
                    "Test",
                    style: TextStyle(
                      color: Colors.cyanAccent,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                TextButton(
                  onPressed: () {
                    _speakQuestion(lession ?? "");
                  },
                  child: const Text(
                    "🔁 Listen Again",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      decoration: TextDecoration.underline,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),

        const SizedBox(height: 30),
      ],
    );
  }

  Widget wordArrange() {
    return Column(
      children: [
        // Selected words display
        Container(
          height: 60,
          width: double.infinity,
          decoration: BoxDecoration(
            border: Border.all(
              color: Colors.cyanAccent.withOpacity(0.3),
              width: 1.2,
            ),
            borderRadius: BorderRadius.circular(12),
          ),
          alignment: Alignment.center,
          child: Text(
            selectedIndexes.isEmpty
                ? ""
                : selectedIndexes.map((i) => options[i]).join(" "), // 👈 FIX
            style: const TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),

        const SizedBox(height: 30),

        // Word buttons
        Wrap(
          alignment: WrapAlignment.center,
          spacing: 12,
          runSpacing: 12,
          children: List.generate(options.length, (index) {
            final word = options[index];

            return GestureDetector(
              onTap: () => _onWordTap(index), // 👈 index भेज रहे हैं
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding:
                    const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
                decoration: BoxDecoration(
                  color: selectedIndexes.contains(index)
                      ? Colors.cyanAccent.withOpacity(0.3)
                      : Colors.transparent,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: selectedIndexes.contains(index)
                        ? Colors.cyanAccent
                        : Colors.cyanAccent.withOpacity(0.3),
                    width: 1.5,
                  ),
                ),
                child: Text(
                  word,
                  style: TextStyle(
                    color: selectedIndexes.contains(index)
                        ? Colors.cyanAccent
                        : Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            );
          }),
        ),

        const SizedBox(height: 30),
        // Check & listen again buttons
        Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: selectedIndexes.isNotEmpty ? _onCheck : null,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.transparent,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 40, vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                      side: const BorderSide(
                          color: Colors.cyanAccent, width: 1.5),
                    ),
                    shadowColor: Colors.cyanAccent.withOpacity(0.6),
                  ),
                  child: const Text(
                    "CHECK",
                    style: TextStyle(
                      color: Colors.cyanAccent,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                TextButton(
                  onPressed: () {
                    _speakQuestion(questionText ?? "");
                  },
                  child: const Text(
                    "🔁 Listen Again",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      decoration: TextDecoration.underline,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ],
    );
  }
}
