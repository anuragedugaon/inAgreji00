import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'package:flutter_tts/flutter_tts.dart';

import '../../../services/video_player.dart';
import '../../ai_teacher/ai_service.dart';

class FillTheBlankScreen extends StatefulWidget {
  final String question;

  List<String> word;

  String answer;

  FillTheBlankScreen(
      {super.key,
      required this.question,
      required this.word,
      required this.answer});

  @override
  State<FillTheBlankScreen> createState() => _FillTheBlankScreenState();
}

class _FillTheBlankScreenState extends State<FillTheBlankScreen>
    with SingleTickerProviderStateMixin {
  final FlutterTts flutterTts = FlutterTts();

  int? selectedIndex;
  bool answered = false;

  // 🎨 Theme constants
  static const Color backgroundColor = Colors.black;
  static const Color accentColor = Colors.cyanAccent;
  static const Color glowColor = Color(0xFF80FFFF);
  static const Color textColor = Colors.white;
  static const Color correctOptionColor = Colors.cyanAccent;
  bool _isLoading = true;

  List<String> options = [];
  String correctAnswer = "";
  String questionText = "";

  @override
  void initState() {

    super.initState();
    _speakQuestion();
    options = widget.word;
    correctAnswer =widget.answer;
   questionText = widget.question;
   setState(() {
     
   });
  }

  /// 🔊 AI Teacher reads the question clearly and slowly
  Future<void> _speakQuestion() async {
    await flutterTts.setLanguage("en-IN");
    await flutterTts.setPitch(1.0); // Normal tone
    await flutterTts.setSpeechRate(0.55); // 👈 Slower and natural speed
    await flutterTts.setVolume(1.0);
    await flutterTts.speak("He blank to the market.");
  }

  @override
  void dispose() {
    flutterTts.stop();
    super.dispose();
  }

  /// 🧠 Checks answer and gives spoken feedback, but stays on screen
  void _checkAnswer() async {
    if (selectedIndex == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please select an answer first!")),
      );
      return;
    }

    final selectedAnswer = options[selectedIndex!];

    if (selectedAnswer == correctAnswer) {
      await flutterTts.setSpeechRate(0.6);
      await flutterTts.speak("Correct! He goes to the market.");

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("✅ Correct!"),
          backgroundColor: Colors.green,
        ),
      );

      // ✅ Navigate to the Lesson Path screen after a short delay
      Future.delayed(const Duration(seconds: 2), () {
        if (mounted) {
          Navigator.pushReplacementNamed(context, '/lesson');
        }
      });
    } else {
      await flutterTts.setSpeechRate(0.6);
      await flutterTts.speak("That’s not correct. Try again!");

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("❌ Incorrect, try again."),
          backgroundColor: Colors.redAccent,
        ),
      );
    }
  }

  // Future<void> loadQuestion() async {
  //   final data = await AIService().getFillQuestion("English Grammar");

  //   if (data.containsKey("error")) {
  //     setState(() {
  //       _isLoading = false;
  //       questionText = "Error loading question!";
  //     });
  //     return;
  //   }

  //   setState(() {
  //     _isLoading = false;
  //     questionText = data["question"];
  //     options = List<String>.from(data["wordList"]);
  //     correctAnswer = data["answer"];
  //   });
  // }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        // 🔙 Go to the Lesson screen instead of Splash
        Navigator.pushReplacementNamed(context, '/lesson');
        return false; // prevent default back
      },
      child: Scaffold(
        backgroundColor: backgroundColor,
        body:SafeArea(
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      // 🏷 Title
                      const Text(
                        "Fill in the Blanks",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: accentColor,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 20),

                      // 👩‍🏫 AI Teacher Animation
                      // Lottie.asset(
                      //   'assets/animations/teacher_idle.json',
                      //   height: 140,
                      //   repeat: true,
                      // ),
                      SizedBox(
                        height: 140, // 👈 Fixed safe height for all devices
                        child: TeacherAnimation(isSpeaking: true),
                      ),

                      const SizedBox(height: 20),

                      // ❓ Question text
                      Text(
                        questionText,
                        style: TextStyle(
                          color: textColor,
                          fontSize: 22,
                          fontWeight: FontWeight.w500,
                        ),
                      ),

                      const SizedBox(height: 40),

                      // 🧱 Options
                      for (int i = 0; i < options.length; i++) ...[
                        _buildOption(i, options[i]),
                        const SizedBox(height: 18),
                      ],

                      const SizedBox(height: 40),

                      // 🚀 Continue Button
                      ElevatedButton(
                        onPressed: _checkAnswer,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.transparent,
                          padding: const EdgeInsets.symmetric(
                              horizontal: 50, vertical: 16),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                            side: const BorderSide(
                                color: accentColor, width: 1.8),
                          ),
                          shadowColor: accentColor.withOpacity(0.6),
                        ),
                        child: const Text(
                          "Continue",
                          style: TextStyle(
                            color: accentColor,
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),

                      const SizedBox(height: 20),

                      // 🕊️ Optional replay button
                      TextButton(
                        onPressed: _speakQuestion,
                        child: const Text(
                          "🔁 Listen Again",
                          style: TextStyle(
                            color: accentColor,
                            fontSize: 16,
                            fontWeight: FontWeight.w500,
                            decoration: TextDecoration.underline,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
      ),
    );
  }

  /// ✅ Option Builder
  Widget _buildOption(int index, String text) {
    final bool isSelected = selectedIndex == index;

    return GestureDetector(
      onTap: () {
        setState(() {
          selectedIndex = index;
        });
      },
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
        decoration: BoxDecoration(
          color: isSelected
              ? correctOptionColor.withOpacity(0.2)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected ? correctOptionColor : accentColor,
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: glowColor.withOpacity(0.4),
              blurRadius: 8,
              spreadRadius: 1,
            ),
          ],
        ),
        child: Center(
          child: Text(
            text,
            style: TextStyle(
              color: isSelected ? correctOptionColor : textColor,
              fontSize: 18,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
      ),
    );
  }
}
