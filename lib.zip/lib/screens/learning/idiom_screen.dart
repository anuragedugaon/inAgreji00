import 'dart:math';
import 'package:flutter/material.dart';
import 'package:inangreji_flutter/screens/ai_teacher/ai_service.dart';
import 'package:provider/provider.dart';
import '../../provider/app_provider.dart';

class IdiomScreen extends StatefulWidget {
  const IdiomScreen({super.key});

  @override
  State<IdiomScreen> createState() => _IdiomScreenState();
}

// class _IdiomScreenState extends State<IdiomScreen> {
//   static const Color kBackground = Colors.black;
//   static const Color kText = Colors.white;
//   static const Color kAccentBlue = Colors.cyanAccent;
//   static const Color kGlow = Color(0xFF00FFFF);

//   Map<String, dynamic>? _currentIdiom;
//   List<dynamic> _idioms = [];
// List<Map<String, dynamic>> _questions = [];
// Map<String, dynamic>? _currentQuestion;
// bool _isLoading = false; // 🔹 Loading flag

//   @override
//   void initState() {
//     super.initState();
//     _loadQuestions();
//   }

// void _showAnotherIdiom() {
//   if (_questions.isEmpty) return;
//   setState(() {
//     _currentQuestion = _questions[Random().nextInt(_questions.length)];
//   });
// }

// Future<void> _loadQuestions() async {
//   setState(() {
//     _isLoading = true;
//   });

//   try {
//     final aiService = AIService();

//     // List of phrases to fetch
//     List<String> phrases = ["Break the ice", "Hit the sack", "Bite the bullet"];
//     List<Map<String, dynamic>> idioms = [];

//     for (String phrase in phrases) {
//       Map<String, dynamic> result = await aiService.getIdiomPhrase(phrase);

//       // Skip if there was an error
//       if (!result.containsKey("error")) {
//         idioms.add(result);
//       } else {
//         debugPrint("Error fetching idiom for '$phrase': ${result['error']}");
//       }
//     }

//     if (idioms.isNotEmpty) {
//       setState(() {
//         _questions = idioms;
//         _currentQuestion = _questions[Random().nextInt(_questions.length)];
//         debugPrint("Loaded idioms: $_questions");
//       });
//     }
//   } catch (e) {
//     debugPrint("Error loading questions: $e");
//   } finally {
//     setState(() {
//       _isLoading = false;
//     });
//   }
// }

//   @override
//   Widget build(BuildContext context) {
//     final appProvider = Provider.of<AppProvider>(context);

//     return WillPopScope(
//       onWillPop: () async {
//         Navigator.pushReplacementNamed(context, '/lesson'); // ✅ Back to /lesson
//         return false;
//       },
//       child: Scaffold(
//         backgroundColor: kBackground,
//         appBar: AppBar(
//           backgroundColor: kBackground,
//           elevation: 0,
//           leading: IconButton(
//             icon: const Icon(Icons.arrow_back_ios, color: kAccentBlue),
//             onPressed: () => Navigator.pushReplacementNamed(
//                 context, '/lesson'), // ✅ Navigate to /lesson
//           ),
//         ),
//         body:_isLoading
//             ? const Center(
//                 child: CircularProgressIndicator(color: kAccentBlue),
//               )
//             : SafeArea(
//                 child: Padding(
//                   padding:
//                       const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
//                   child: _currentIdiom == null
//                       ? const Center(
//                           child: Text(
//                             "No idioms available.",
//                             style: TextStyle(color: kAccentBlue, fontSize: 18),
//                           ),
//                         )
//                       : Column(
//                           crossAxisAlignment: CrossAxisAlignment.center,
//                           children: [
//                             // 🔹 Title
//                             const Text(
//                               "Idiom of the Day",
//                               style: TextStyle(
//                                 color: kAccentBlue,
//                                 fontSize: 22,
//                                 fontWeight: FontWeight.bold,
//                               ),
//                               textAlign: TextAlign.center,
//                             ),
//                             const SizedBox(height: 30),

//                             // 🔹 Decorative Icon
//                             const Icon(Icons.ac_unit,
//                                 color: kAccentBlue, size: 80),
//                             const SizedBox(height: 25),

//                             // 🔹 Idiom Phrase
//                             Text(
//                               _currentIdiom?['phrase'] ?? '',
//                               style: const TextStyle(
//                                 color: kAccentBlue,
//                                 fontSize: 26,
//                                 fontWeight: FontWeight.bold,
//                               ),
//                             ),
//                             const SizedBox(height: 30),

//                             // 🔹 Meaning
//                             _buildInfoSection(
//                               title: "Meaning",
//                               content: _currentIdiom?['meaning'] ?? '—',
//                             ),
//                             const SizedBox(height: 15),

//                             // 🔹 Example
//                             _buildInfoSection(
//                               title: "Example",
//                               content: _currentIdiom?['example'] ?? '—',
//                             ),
//                             const SizedBox(height: 15),

//                             // 🔹 Origin
//                             _buildInfoSection(
//                               title: "Origin",
//                               content:
//                                   _currentIdiom?['origin'] ?? 'Not available',
//                             ),

//                             const Spacer(),

//                             // 🔹 "Learn Another" Button
//                             SizedBox(
//                               width: double.infinity,
//                               child: ElevatedButton(
//                                 onPressed: _showAnotherIdiom,
//                                 style: ElevatedButton.styleFrom(
//                                   backgroundColor: Colors.transparent,
//                                   padding:
//                                       const EdgeInsets.symmetric(vertical: 16),
//                                   shape: RoundedRectangleBorder(
//                                     borderRadius: BorderRadius.circular(12),
//                                     side: const BorderSide(
//                                         color: kAccentBlue, width: 1.5),
//                                   ),
//                                   elevation: 8,
//                                   shadowColor: kGlow.withOpacity(0.6),
//                                 ),
//                                 child: const Text(
//                                   "Learn Another",
//                                   style: TextStyle(
//                                     color: kAccentBlue,
//                                     fontSize: 18,
//                                     fontWeight: FontWeight.bold,
//                                   ),
//                                 ),
//                               ),
//                             ),
//                             const SizedBox(height: 20),
//                           ],
//                         ),
//                 ),
//               ),
//       ),
//     );
//   }

//   static Widget _buildInfoSection(
//       {required String title, required String content}) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         Text(
//           title,
//           style: const TextStyle(
//             color: kAccentBlue,
//             fontSize: 16,
//             fontWeight: FontWeight.bold,
//           ),
//         ),
//         const SizedBox(height: 6),
//         Text(
//           content,
//           style: const TextStyle(
//             color: kText,
//             fontSize: 15,
//             height: 1.4,
//           ),
//         ),
//       ],
//     );
//   }






class _IdiomScreenState extends State<IdiomScreen> {
  static const Color kBackground = Colors.black;
  static const Color kText = Colors.white;
  static const Color kAccentBlue = Colors.cyanAccent;
  static const Color kGlow = Color(0xFF00FFFF);

  Map<String, dynamic>? _currentIdiom;
  List<Map<String, dynamic>> _idioms = [];
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _loadIdioms();
  }

  void _showAnotherIdiom() {
    if (_idioms.isEmpty) return;
    setState(() {
      _currentIdiom = _idioms[Random().nextInt(_idioms.length)];
    });
  }

  Future<void> _loadIdioms() async {
    setState(() {
      _isLoading = true;
    });

    try {
      final aiService = AIService();
      List<String> phrases = ["Break the ice", "Hit the sack", "Bite the bullet"];
      List<Map<String, dynamic>> idioms = [];

      for (String phrase in phrases) {
        Map<String, dynamic> result = await aiService.getIdiomPhrase(phrase);

        // Skip if error
        if (!result.containsKey("error")) {
          idioms.add(result);
        } else {
          debugPrint("Error fetching idiom for '$phrase': ${result['error']}");
        }
      }

      if (idioms.isNotEmpty) {
        setState(() {
          _idioms = idioms;
          _currentIdiom = _idioms[Random().nextInt(_idioms.length)];
          debugPrint("Loaded idioms: $_idioms");
        });
      }
    } catch (e) {
      debugPrint("Error loading idioms: $e");
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBackground,
      appBar: AppBar(
        backgroundColor: kBackground,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: kAccentBlue),
          onPressed: () => Navigator.pushReplacementNamed(context, '/lesson'),
        ),
      ),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(color: kAccentBlue),
            )
          : SafeArea(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
                child: _currentIdiom == null
                    ? const Center(
                        child: Text(
                          "No idioms available.",
                          style: TextStyle(color: kAccentBlue, fontSize: 18),
                        ),
                      )
                    : Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          const Text(
                            "Idiom of the Day",
                            style: TextStyle(
                              color: kAccentBlue,
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                            ),
                            textAlign: TextAlign.center,
                          ),
                          const SizedBox(height: 30),
                          const Icon(Icons.ac_unit, color: kAccentBlue, size: 80),
                          const SizedBox(height: 25),

                          // 🔹 Idiom Phrase
                          Text(
                            _currentIdiom?['idiom'] ?? '',
                            style: const TextStyle(
                              color: kAccentBlue,
                              fontSize: 26,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 30),

                          // 🔹 Meaning
                          _buildInfoSection(
                            title: "Meaning",
                            content: _currentIdiom?['meaning'] ?? '—',
                          ),
                          const SizedBox(height: 15),

                          // 🔹 Example
                          _buildInfoSection(
                            title: "Example",
                            content: _currentIdiom?['example'] ?? '—',
                          ),
                          const SizedBox(height: 15),

                          // 🔹 Explanation
                          _buildInfoSection(
                            title: "Explanation",
                            content: _currentIdiom?['explanation'] ?? 'Not available',
                          ),

                          const Spacer(),

                          // 🔹 "Learn Another" Button
                          SizedBox(
                            width: double.infinity,
                            child: ElevatedButton(
                              onPressed: _showAnotherIdiom,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.transparent,
                                padding: const EdgeInsets.symmetric(vertical: 16),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  side: const BorderSide(color: kAccentBlue, width: 1.5),
                                ),
                                elevation: 8,
                                shadowColor: kGlow.withOpacity(0.6),
                              ),
                              child: const Text(
                                "Learn Another",
                                style: TextStyle(
                                  color: kAccentBlue,
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),
                        ],
                      ),
              ),
            ),
    );
  }

  static Widget _buildInfoSection({required String title, required String content}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            color: kAccentBlue,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 6),
        Text(
          content,
          style: const TextStyle(
            color: kText,
            fontSize: 15,
            height: 1.4,
          ),
        ),
      ],
    );
  }
}
