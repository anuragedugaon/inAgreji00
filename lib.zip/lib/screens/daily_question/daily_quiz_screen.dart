import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../services/video_player.dart';
import '../ai_teacher/ai_service.dart';

class DailyQuizScreen extends StatefulWidget {
  const DailyQuizScreen({super.key});

  @override
  State<DailyQuizScreen> createState() => _DailyQuizScreenState();
}

class _DailyQuizScreenState extends State<DailyQuizScreen> {
  final FlutterTts tts = FlutterTts();

  List<dynamic> questions = [];
  int currentIndex = 0;
  int score = 0;
  int? selectedIndex;
  bool loading = true;
  String errorMessage = "";

  // 🎨 Theme constants
  static const Color backgroundColor = Colors.black;
  static const Color accentColor = Colors.cyanAccent;
  static const Color glowColor = Color(0xFF80FFFF);
  static const Color textColor = Colors.white;
  static const Color correctOptionColor = Colors.cyanAccent;

  @override
  void initState() {
    super.initState();
    loadQuestions();
  }

  Future<void> loadQuestions() async {
    final prefs = await SharedPreferences.getInstance();
    final selectedLang =
        "${prefs.getString('selected_language')?.toLowerCase() ?? 'english'} Grammar  ";
    questions = await AIService().getCachedDailyQuestions(selectedLang);
    setState(() => loading = false);
        errorMessage = questions.isEmpty ? "No questions found." : "";

    _speak(questions[currentIndex]["question"]);
  }

  Future<void> _speak(String text) async {
    final prefs = await SharedPreferences.getInstance();
    final selectedLangCode =
        prefs.getString('selected_language_code')?.toLowerCase() ?? 'en';

    debugPrint("🗣️ Speaking in $selectedLangCode: $text");
    errorMessage = text;
    await tts.setLanguage(selectedLangCode);
    await tts.setPitch(1.0);
    await tts.setSpeechRate(0.55);
    await tts.speak(text);
  }

  void checkAnswer() async {
    if (selectedIndex == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please select an answer first!")),
      );
      return;
    }

    final selected = questions[currentIndex]["options"][selectedIndex!];
    final correct = questions[currentIndex]["answer"];

    if (selected == correct) {
      score++;
      await _speak("Correct!");
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("✅ Correct!"),
          backgroundColor: Colors.green,
        ),
      );
    } else {
      await _speak("Incorrect, correct answer is $correct");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("❌ Incorrect! Correct: $correct"),
          backgroundColor: Colors.redAccent,
        ),
      );
    }

    Future.delayed(const Duration(seconds: 1), () {
      if (currentIndex < questions.length - 1) {
        setState(() {
          currentIndex++;
          selectedIndex = null;
        });
        _speak(questions[currentIndex]["question"]);
      } else {
        showResult();
      }
    });
  }

  void showResult() async {
    await _speak("Your score is $score out of 5");
    if (!mounted) return;
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      body: loading
          ? const Center(
              child: CircularProgressIndicator(color: accentColor),
            )
          : SafeArea(
              child:Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 30),
                  child: questions.isEmpty
                      ? Center(
                        child: Text(
                              " $errorMessage",
                              style: TextStyle(
                                  color: accentColor,
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold),
                            ),
                      )
                        
                      :  SingleChildScrollView(
                child: Column(
                          children: [
                            const Text(
                              "Daily Test",
                              style: TextStyle(
                                  color: accentColor,
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 15),

                            // 👩‍🏫 Teacher
                            SizedBox(
                                height: 140,
                                child: TeacherAnimation(isSpeaking: true)),

                            const SizedBox(height: 20),

                            // ❓ Question
                            Text(
                              questions[currentIndex]["question"],
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                  color: textColor,
                                  fontSize: 22,
                                  fontWeight: FontWeight.w500),
                            ),

                            const SizedBox(height: 30),

                            // Options
                            ...List.generate(
                              questions[currentIndex]["options"].length,
                              (i) => Column(
                                children: [
                                  _buildOption(
                                      i, questions[currentIndex]["options"][i]),
                                  const SizedBox(height: 18),
                                ],
                              ),
                            ),

                            const SizedBox(height: 30),

                            // Continue
                            ElevatedButton(
                              onPressed: checkAnswer,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.transparent,
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 50, vertical: 16),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(14),
                                  side: const BorderSide(
                                      color: accentColor, width: 1.8),
                                ),
                                shadowColor: accentColor.withOpacity(0.6),
                              ),
                              child: const Text(
                                "Continue",
                                style: TextStyle(
                                    color: accentColor,
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold),
                              ),
                            ),

                            TextButton(
                              onPressed: () =>
                                  _speak(questions[currentIndex]["question"]),
                              child: const Text(
                                "🔁 Listen Again",
                                style: TextStyle(
                                    color: accentColor,
                                    decoration: TextDecoration.underline,
                                    fontSize: 16),
                              ),
                            )
                          ],
                        ),
                ),
              ),
            ),
    );
  }

  // 🧱 Option Builder
  Widget _buildOption(int index, String text) {
    final isSelected = selectedIndex == index;
    return GestureDetector(
      onTap: () => setState(() => selectedIndex = index),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
        decoration: BoxDecoration(
          color: isSelected
              ? correctOptionColor.withOpacity(0.2)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected ? correctOptionColor : accentColor,
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: glowColor.withOpacity(0.4),
              blurRadius: 8,
              spreadRadius: 1,
            ),
          ],
        ),
        child: Center(
          child: Text(
            text,
            style: TextStyle(
              color: isSelected ? correctOptionColor : textColor,
              fontSize: 18,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
      ),
    );
  }
}
