import 'package:flutter/material.dart';

class PaymentMethodScreen extends StatefulWidget {
  const PaymentMethodScreen({super.key});

  @override
  State<PaymentMethodScreen> createState() => _PaymentMethodScreenState();
}

class _PaymentMethodScreenState extends State<PaymentMethodScreen> {
  // Selected Payment Option
  String selectedMethod = "Credit Card"; // Default selection

  // Theme Colors
  static const Color kBackground = Colors.black;
  static const Color kBorder = Colors.cyanAccent;
  static const Color kGlow = Color(0xFF80FFFF);
  static const Color kText = Colors.white;
  static const Color kCardFill = Color(0xFF1C1C1E);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBackground,
      appBar: AppBar(
        backgroundColor: kBackground,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: kBorder),
          onPressed: () => Navigator.pop(context),
        ),
        centerTitle: true,
        title: const Icon(Icons.lock, color: kBorder, size: 28),
      ),

      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
        child: Column(
          children: [
            // ✅ Title
            const Text(
              "Payment Method",
              style: TextStyle(
                color: kBorder,
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),

            const SizedBox(height: 30),

            // ✅ Payment Options
            _buildPaymentOption("UPI"),
            const SizedBox(height: 16),
            _buildPaymentOption("Credit Card"),
            const SizedBox(height: 16),
            _buildPaymentOption("Paytm"),

            const Spacer(),

            // ✅ Confirm Payment Button
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  // TODO: Handle confirm payment
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text("Selected: $selectedMethod")),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                    side: const BorderSide(color: kBorder, width: 1.5),
                  ),
                  elevation: 8,
                  shadowColor: kGlow.withOpacity(0.6),
                ),
                child: const Text(
                  "Confirm Payment",
                  style: TextStyle(
                    color: kBorder,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),

            const SizedBox(height: 20),
          ],
        ),
      ),

      // ✅ Bottom Navigation Bar
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: kCardFill,
        type: BottomNavigationBarType.fixed,
        selectedItemColor: kBorder,
        unselectedItemColor: Colors.white70,
        currentIndex: 3, // Profile highlighted
        onTap: (index) {
          // TODO: Add navigation
        },
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
          BottomNavigationBarItem(icon: Icon(Icons.track_changes), label: "Track"),
          BottomNavigationBarItem(icon: Icon(Icons.book), label: "Lessons"),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profile"),
        ],
      ),
    );
  }

  /// ✅ Builds a single payment option card
  Widget _buildPaymentOption(String method) {
    final bool isSelected = selectedMethod == method;
    return GestureDetector(
      onTap: () {
        setState(() {
          selectedMethod = method;
        });
      },
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
        decoration: BoxDecoration(
          color: kCardFill,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected ? kBorder : Colors.white54,
            width: 1.5,
          ),
          boxShadow: isSelected
              ? [
            BoxShadow(
              color: kGlow.withOpacity(0.5),
              blurRadius: 10,
              spreadRadius: 2,
            )
          ]
              : [],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              method,
              style: TextStyle(
                color: isSelected ? kBorder : kText,
                fontSize: 16,
                fontWeight: FontWeight.w500,
              ),
            ),
            if (isSelected)
              const Icon(Icons.check, color: kBorder, size: 20),
          ],
        ),
      ),
    );
  }
}
