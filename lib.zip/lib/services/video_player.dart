import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'video_manager.dart';

class TeacherAnimation extends StatelessWidget {
  final bool isSpeaking;
  const TeacherAnimation({super.key, required this.isSpeaking});

  @override
  Widget build(BuildContext context) {
    final controller = VideoManager.controller;

    if (isSpeaking) {
      controller?.play();
    } else {
      controller?.pause();
    }

    return SizedBox(
      height: 500,
      width: 400,
      child: Image.asset("assets/video/human_teacher2.gif"),
      
      // controller != null && controller.value.isInitialized
      //     ? ClipRRect(
      //         borderRadius: BorderRadius.circular(10),
      //         child: VideoPlayer(controller),
      //       )
      //     : const Center(child: CircularProgressIndicator()),
    );
  }
}
