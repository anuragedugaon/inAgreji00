import 'package:video_player/video_player.dart';

class VideoManager {
  static VideoPlayerController? controller;

  static Future<void> initialize() async {
    controller = VideoPlayerController.asset("human_teacher3.mp4");
    await controller?.initialize();
    controller?.setLooping(true);
  }
}
