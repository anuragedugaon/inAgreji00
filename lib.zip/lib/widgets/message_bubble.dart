// lib/widgets/message_bubble.dart
import 'package:flutter/material.dart';

class MessageBubble extends StatelessWidget {
  final String text;
  final bool isUser;
  final bool isFading; // 👈 add this

  const MessageBubble({
    Key? key,
    required this.text,
    required this.isUser,
    this.isFading = false, // 👈 default false
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final Color normalColor = isUser ? Colors.blue[800]! : Colors.green[800]!;
    final Color fadedColor = Colors.grey[500]!;

    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: isUser ? Colors.blue[100] : Colors.green[100],
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              isUser ? 'You' : 'AI Teacher',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 12,
                color: isUser ? normalColor : Colors.green[800],
              ),
            ),
            const SizedBox(height: 4),

            // 🎨 Fade animation for message text
            AnimatedDefaultTextStyle(
              duration: const Duration(milliseconds: 500),
              style: TextStyle(
                fontSize: 16,
                color: isFading ? fadedColor : normalColor,
              ),
              child: Text(text),
            ),
          ],
        ),
      ),
    );
  }
}
