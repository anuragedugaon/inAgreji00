import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class PaymentProvider extends ChangeNotifier {
  late Razorpay _razorpay;

  String baseUrl = "https://inangreji.in/api/"; // ⚠️ change your domain

  bool isLoading = false;
  String paymentStatus = "";
  String paymentId = "";
  String? subscriptionId; // 🚀 store subscription id

  // 🚀 Initialize Razorpay listeners
  PaymentProvider() {
    _razorpay = Razorpay();
    _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handleSuccess);
    _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _handleError);
    _razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
  }

  @override
  void dispose() {
    _razorpay.clear();
    super.dispose();
  }
    
  // 🔥 1) Create Subscription using PHP
  Future<void> createSubscription({
    required String planId,
    required String name,
    required String email,
    required String phone,
    required String totalCount,
  }) async {
      final prefs = await SharedPreferences.getInstance();
      final storedToken = prefs.getString('auth_token');
    try {
      isLoading = true;
      notifyListeners();

      final res = await http.post(
        Uri.parse("${baseUrl}create-subscription"),
        headers: {
          'Authorization': 'Bearer $storedToken',},
        body: { "plan_id": planId,"total_count": totalCount },
      );

      final data = jsonDecode(res.body);

      debugPrint(" Subscription Response: $data"  );

      if (data["id"] != null) {
        subscriptionId = data["id"];
        _openSubscriptionCheckout(
          name: name,
          email: email,
          phone: phone,
        );
      } else {
        paymentStatus = "Subscription Creation Failed ❌";
                    debugPrint("Subscription Creation Failed ❌"  );

      }
    } catch (e) {
            debugPrint(" Subscription  Creation Failed : $e"  );

      paymentStatus = "Server Error ❗ ($e)";
    }

    isLoading = false;
    notifyListeners();
  }

  // 🚪 2) Open Razorpay Subscription Checkout
  void _openSubscriptionCheckout({
    required String name,
    required String email,
    required String phone,
  }) {
    var options = {
      "key": "YOUR_RAZORPAY_KEY_ID",  // ⚠️ Replace
      "subscription_id": subscriptionId,
      "name": name,
      "description": "Subscription Payment",
      "prefill": {"contact": phone, "email": email},
    };

    try {
      _razorpay.open(options);
    } catch (e) {
      debugPrint("CHECKOUT ERROR: $e");
    }
  }

  // 🎉 3) On Successful Payment
  void _handleSuccess(PaymentSuccessResponse response) async {
    paymentId = response.paymentId!;
    paymentStatus = "Subscription Payment Successful 🎉";

    await verifySubscription(
      paymentId: response.paymentId!,
      signature: response.signature,
      subscriptionId: subscriptionId,
    );
    notifyListeners();
  }

  // ❌ 4) On Failed Payment
  void _handleError(PaymentFailureResponse response) {
    paymentStatus = "Subscription Payment Failed ❌";
    notifyListeners();
  }

  // 💰 5) Wallet Payments
  void _handleExternalWallet(ExternalWalletResponse response) {
    paymentStatus = "Wallet Selected: ${response.walletName}";
    notifyListeners();
  }

  // 🔐 6) Verify Subscription Payment with PHP
  Future<void> verifySubscription({
    required String paymentId,
    required String? signature,
    required String? subscriptionId,
  }) async {
        final prefs = await SharedPreferences.getInstance();
      final storedToken = prefs.getString('auth_token');
    try {
      final res = await http.post(
        Uri.parse("${baseUrl}verify-payment"),
        headers: {
          'Authorization': 'Bearer $storedToken',}, 
        body: {
          "razorpay_payment_id": paymentId,
          "razorpay_signature": signature,
          "razorpay_order_id": subscriptionId,
        },
      );

      final data = jsonDecode(res.body);

      if (data["status"] == "success") {
        paymentStatus = "Subscription Verified ✔";
      } else {
        paymentStatus = "Verification Failed ❌";
      }
    } catch (e) {
      paymentStatus = "Verification Server Error ❗";
    }

    notifyListeners();
  }
}
