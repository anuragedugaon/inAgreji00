// lib/provider/app_provider.dart
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/api_client.dart';
import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:inangreji_flutter/screens/ai_teacher/ai_service.dart';

class AppProvider extends ChangeNotifier {
  Locale _locale = const Locale('en');
  Map<String, String> _localizedStrings = {};

  Locale get locale => _locale;
  String translate(String key) => _localizedStrings[key] ?? key;

  bool _isLoading = false;
  String? _token;

  bool get isLoading => _isLoading;
  String? get token => _token;

  Future<bool> login(String email, String password) async {
    _isLoading = true;
    notifyListeners();

    try {
      final response = await ApiClient.postRequest(
        '/api/login',
        {
          'email': email,
          'password': password,
        },
      );

      debugPrint("🔹 Login Response: $response");

      if (response['success'] == true) {
        _token = response['token'];
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('auth_token', _token!);
        _isLoading = false;
        notifyListeners();
        debugPrint("✅ Login successful");
        return true;
      } else {
        _isLoading = false;
        notifyListeners();
        debugPrint("⚠️ Login failed: ${response['message']}");
        return false;
      }
    } catch (e) {
      _isLoading = false;
      notifyListeners();
      debugPrint("❌ Login error: $e");
      return false;
    }
  }

  /// 🌐 Load saved language and its strings
  Future<void> loadLocale() async {
    final prefs = await SharedPreferences.getInstance();
    final langCode = prefs.getString('selected_language_code') ?? 'en';
    _locale = Locale(langCode);
    await _loadLanguageFile(langCode);
    notifyListeners();
  }

  /// 🌍 Change language at runtime
  Future<void> changeLanguage(String langCode) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('selected_language_code', langCode);

    _locale = Locale(langCode);

    await _loadLanguageFile(langCode);

    try {
      // 🔄 Reinitialize TTS for the selected language
      await AIService().refreshVoice();
      debugPrint("✅ AI voice updated for new language: $langCode");
    } catch (e) {
      debugPrint("⚠️ Error updating AI voice: $e");
    }

    notifyListeners();
  }

  /// 📂 Load JSON from assets
  Future<void> _loadLanguageFile(String langCode) async {
    final jsonString = await rootBundle.loadString('lib/l10n/$langCode.json');
    final Map<String, dynamic> jsonMap = json.decode(jsonString);
    _localizedStrings =
        jsonMap.map((key, value) => MapEntry(key, value.toString()));
  }

  /// 🔒 Proper Logout Implementation
  Future<bool> logout() async {
    _isLoading = true;
    notifyListeners();

    try {
      final prefs = await SharedPreferences.getInstance();
      final storedToken = prefs.getString('auth_token');

      if (storedToken == null) {
        debugPrint("No token found in storage.");
        _isLoading = false;
        notifyListeners();
        return false;
      }

      final response = await ApiClient.postRequestWithAuth(
        '/api/logout',
        {},
        storedToken,
      );

      if (response['status'] == true) {
        await prefs.remove('auth_token');
        _token = null;
        _isLoading = false;
        notifyListeners();
        debugPrint("Logout successful.");
        return true;
      } else {
        _isLoading = false;
        notifyListeners();
        debugPrint("Logout failed: ${response['message']}");
        return false;
      }
    } catch (e) {
      _isLoading = false;
      notifyListeners();
      debugPrint("Logout error: $e");
      return false;
    }
  }

  // Get User  Lessons
  /// 📘 Fetch User Lessons
  Future<List<dynamic>> getUserLessons() async {
    _isLoading = true;
    notifyListeners();

    try {
      final prefs = await SharedPreferences.getInstance();
      final storedToken = prefs.getString('auth_token');

      if (storedToken == null) {
        debugPrint("No token found. Please log in first.");
        _isLoading = false;
        notifyListeners();
        return [];
      }

      final response = await ApiClient.getRequestWithAuth(
        '/api/get-user-lessons',
        storedToken,
      );

      if (response['status'] == true) {
        debugPrint("✅ Lessons fetched successfully");
        _isLoading = false;
        notifyListeners();
        return response['data'] ?? [];
      } else {
        debugPrint("⚠️ Failed to fetch lessons: ${response['message']}");
        _isLoading = false;
        notifyListeners();
        return [];
      }
    } catch (e) {
      debugPrint("❌ Error fetching lessons: $e");
      _isLoading = false;
      notifyListeners();
      return [];
    }
  }

  //Get User Lesson Units
  /// 📗 Fetch User Lesson Units
  Future<List<dynamic>> getUserLessonUnits() async {
    _isLoading = true;
    notifyListeners();

    try {
      final prefs = await SharedPreferences.getInstance();
      final storedToken = prefs.getString('auth_token');

      if (storedToken == null) {
        debugPrint("No token found. Please log in first.");
        _isLoading = false;
        notifyListeners();
        return [];
      }

      final response = await ApiClient.getRequestWithAuth(
        '/api/get-user-lesson-units',
        storedToken,
      );

      if (response['status'] == true) {
        debugPrint("✅ Lesson units fetched successfully");
        _isLoading = false;
        notifyListeners();
        return response['data'] ?? [];
      } else {
        debugPrint("⚠️ Failed to fetch lesson units: ${response['message']}");
        _isLoading = false;
        notifyListeners();
        return [];
      }
    } catch (e) {
      debugPrint("❌ Error fetching lesson units: $e");
      _isLoading = false;
      notifyListeners();
      return [];
    }
  }

  /// 🌍 Fetch Countries API
  Future<Object> getCountries() async {
    _isLoading = true;
    notifyListeners();

    try {
      final prefs = await SharedPreferences.getInstance();
      final storedToken = prefs.getString('auth_token');

      if (storedToken == null) {
        debugPrint("❌ No token found. Please log in first.");
        _isLoading = false;
        notifyListeners();
        return [];
      }

      // ✅ API call using the existing getRequestWithAuth
      final response = await ApiClient.getRequestWithAuth(
        '/api/get-countries',
        storedToken,
      );

      _isLoading = false;
      notifyListeners();

      // ✅ Response is a list (not wrapped in 'data')
      if (response is List) {
        debugPrint("✅ Countries fetched successfully (${response.length})");
        return response;
      } else {
        debugPrint("⚠️ Unexpected response type: $response");
        return [];
      }
    } catch (e) {
      debugPrint("❌ Error fetching countries: $e");
      _isLoading = false;
      notifyListeners();
      return [];
    }
  }

  /// 📚 Fetch Lesson Categories
  Future<List<dynamic>> getLessonCategories() async {
    _isLoading = true;
    notifyListeners();

    try {
      final prefs = await SharedPreferences.getInstance();
      final storedToken = prefs.getString('auth_token');

      if (storedToken == null) {
        debugPrint("❌ No token found. Please log in first.");
        _isLoading = false;
        notifyListeners();
        return [];
      }

      // Make GET request
      final response = await ApiClient.getRequestWithAuth(
        '/api/lesson-category',
        storedToken,
      );

      _isLoading = false;
      notifyListeners();

      // ✅ Validate response structure
      if (response != null && response['lessonCategorys'] != null) {
        final categories = response['lessonCategorys'];
        debugPrint("✅ Lesson categories fetched: ${categories.length}");
        return categories;
      } else {
        debugPrint("⚠️ Unexpected response format: $response");
        return [];
      }
    } catch (e) {
      debugPrint("❌ Error fetching lesson categories: $e");
      _isLoading = false;
      notifyListeners();
      return [];
    }
  }

  /// 🌐 Fetch Available Languages (Debug Version)
  /// 🌐 Fetch Available Languages (Fixed Version)
  Future<List<dynamic>> getLanguages() async {
    _isLoading = true;
    notifyListeners();

    try {
      final prefs = await SharedPreferences.getInstance();
      final storedToken = prefs.getString('auth_token');

      if (storedToken == null) {
        debugPrint("❌ No token found. Using fallback language list.");
        _isLoading = false;
        notifyListeners();

        // 🟢 fallback for first-time users or testing
        return [
          {'code': 'EN', 'name': 'English'},
          {'code': 'HI', 'name': 'Hindi'},
          {'code': 'BN', 'name': 'Bengali'},
        ];
      }

      // ✅ Corrected endpoint spelling + auth
      final response = await ApiClient.getRequestWithAuth(
        '/api/get-language',
        storedToken,
      );

      debugPrint("🌍 Raw Language API Response: $response");

      _isLoading = false;
      notifyListeners();

      if (response is List) {
        debugPrint("✅ Languages fetched successfully (${response.length})");
        return response;
      }

      if (response is Map<String, dynamic>) {
        if (response['data'] is List) {
          return List<dynamic>.from(response['data']);
        }
        if (response['languages'] is List) {
          return List<dynamic>.from(response['languages']);
        }
      }

      debugPrint("⚠️ Unexpected language response format: $response");
      return [];
    } catch (e) {
      debugPrint("❌ Error fetching languages: $e");

      // ✅ Show fallback on error
      _isLoading = false;
      notifyListeners();
      return [
        {'code': 'EN', 'name': 'English'},
        {'code': 'HI', 'name': 'Hindi'},
        {'code': 'BN', 'name': 'Bengali'},
      ];
    }
  }

  /// 🎯 Fetch Available Purposes
  Future<List<dynamic>> getPurposes() async {
    _isLoading = true;
    notifyListeners();

    try {
      final response = await ApiClient.getRequestWithAuth('/api/get-purposes');
      debugPrint("🌍 Raw Purpose API Response: $response");

      _isLoading = false;
      notifyListeners();

      // ✅ Check response format
      if (response is Map<String, dynamic> && response['purposes'] is List) {
        final purposes = response['purposes'];
        debugPrint("✅ Purposes fetched successfully (${purposes.length})");
        return List<dynamic>.from(purposes);
      }

      debugPrint("⚠️ Unexpected response format: $response");
      return [];
    } catch (e) {
      debugPrint("❌ Error fetching purposes: $e");
      _isLoading = false;
      notifyListeners();
      return [];
    }
  }

  /// 🧠 Fetch Available Levels
  Future<List<dynamic>> getLevels() async {
    _isLoading = true;
    notifyListeners();

    try {
      final response = await ApiClient.getRequestWithAuth('/api/get-levels');
      debugPrint("🌍 Raw Levels API Response: $response");

      _isLoading = false;
      notifyListeners();

      // ✅ Extract levels list from JSON
      if (response is Map<String, dynamic> && response['levels'] is List) {
        final levels = response['levels'];
        debugPrint("✅ Levels fetched successfully (${levels.length})");
        return List<dynamic>.from(levels);
      }

      debugPrint("⚠️ Unexpected response format: $response");
      return [];
    } catch (e) {
      debugPrint("❌ Error fetching levels: $e");
      _isLoading = false;
      notifyListeners();
      return [];
    }
  }


  /// 🏙️ Fetch All Cities
  Future<List<dynamic>> getCities() async {
    _isLoading = true;
    notifyListeners();

    // 🔁 Fallback static cities list so the app always works
    const fallbackCities = [
      {'name': 'Bengaluru'},
      {'name': 'Mumbai'},
      {'name': 'Delhi'},
      {'name': 'Hyderabad'},
      {'name': 'Pune'},
      {'name': 'Chennai'},
      {'name': 'Kolkata'},
      {'name': 'Ahmedabad'},
    ];

    try {
      final prefs = await SharedPreferences.getInstance();
      final storedToken = prefs.getString('auth_token');

      if (storedToken == null || storedToken.isEmpty) {
        debugPrint("❌ No token found. Using fallback city list.");
        _isLoading = false;
        notifyListeners();
        return fallbackCities;
      }

      // ✅ API call using token
      final response = await ApiClient.getRequestWithAuth(
        '/api/get-cities',
        storedToken,
      );

      _isLoading = false;
      notifyListeners();

      // ✅ The API returns a map with key 'cities'
      if (response is Map<String, dynamic> &&
          response['cities'] is List &&
          (response['cities'] as List).isNotEmpty) {
        final cities = List<dynamic>.from(response['cities']);
        debugPrint("🏙️ Cities fetched successfully (${cities.length})");
        return cities;
      } else {
        debugPrint("⚠️ Unexpected cities response: $response, using fallback city list.");
        return fallbackCities;
      }
    } catch (e) {
      debugPrint("❌ Error fetching cities: $e, using fallback city list.");
      _isLoading = false;
      notifyListeners();
      return fallbackCities;
    }
  }

  /// 🏆 Fetch Achievements
  Future<List<dynamic>> getAchievements() async {
    _isLoading = true;
    notifyListeners();

    try {
      final prefs = await SharedPreferences.getInstance();
      final storedToken = prefs.getString('auth_token');

      if (storedToken == null) {
        debugPrint("❌ No token found. Please log in first.");
        _isLoading = false;
        notifyListeners();
        return [];
      }

      // ✅ Fetch data from API
      final response = await ApiClient.getRequestWithAuth(
        '/api/achievements',
        storedToken,
      );

      _isLoading = false;
      notifyListeners();

      // ✅ Expected structure: { "achievements": [ ... ] }
      if (response is Map<String, dynamic> &&
          response['achievements'] is List) {
        final achievements = response['achievements'];
        debugPrint(
            "🏆 Achievements fetched successfully (${achievements.length})");
        return List<dynamic>.from(achievements);
      } else {
        debugPrint("⚠️ Unexpected achievements response: $response");
        return [];
      }
    } catch (e) {
      debugPrint("❌ Error fetching achievements: $e");
      _isLoading = false;
      notifyListeners();
      return [];
    }
  }

  /// 🧠 Fetch Idioms
  Future<List<dynamic>> getIdioms() async {
    _isLoading = true;
    notifyListeners();

    try {
      final prefs = await SharedPreferences.getInstance();
      final storedToken = prefs.getString('auth_token');

      if (storedToken == null) {
        debugPrint("❌ No token found. Please log in first.");
        _isLoading = false;
        notifyListeners();
        return [];
      }

      // ✅ Call idioms API
      final response = await ApiClient.getRequestWithAuth(
        '/api/idioms',
        storedToken,
      );

      _isLoading = false;
      notifyListeners();

      // ✅ Expected structure: { "idioms": [ ... ] }
      if (response is Map<String, dynamic> && response['idioms'] is List) {
        final idioms = response['idioms'];
        debugPrint("🧠 Idioms fetched successfully (${idioms.length})");
        return List<dynamic>.from(idioms);
      } else {
        debugPrint("⚠️ Unexpected idioms response: $response");
        return [];
      }
    } catch (e) {
      debugPrint("❌ Error fetching idioms: $e");
      _isLoading = false;
      notifyListeners();
      return [];
    }
  }

  /// 🎯 Fetch User Goals
  Future<List<dynamic>> getGoals() async {
    _isLoading = true;
    notifyListeners();

    try {
      final prefs = await SharedPreferences.getInstance();
      final storedToken = prefs.getString('auth_token');

      if (storedToken == null) {
        debugPrint("❌ No token found. Please log in first.");
        _isLoading = false;
        notifyListeners();
        return [];
      }

      // ✅ Make authenticated GET request
      final response = await ApiClient.getRequestWithAuth(
        '/api/get-goals',
        storedToken,
      );

      _isLoading = false;
      notifyListeners();

      // ✅ Expected response: { "goals": [...] }
      if (response is Map<String, dynamic> && response['goals'] is List) {
        final goals = response['goals'];
        debugPrint("🎯 Goals fetched successfully (${goals.length})");
        return List<dynamic>.from(goals);
      } else {
        debugPrint("⚠️ Unexpected goals response format: $response");
        return [];
      }
    } catch (e) {
      debugPrint("❌ Error fetching goals: $e");
      _isLoading = false;
      notifyListeners();
      return [];
    }
  }

  ///Grammar Tips
  ///  /// 🧩 Fetch Grammar Tips
  Future<List<dynamic>> getGrammarTips() async {
    _isLoading = true;
    notifyListeners();

    try {
      // ✅ Get stored token
      final prefs = await SharedPreferences.getInstance();
      final storedToken = prefs.getString('auth_token');

      if (storedToken == null) {
        debugPrint("❌ No token found. Please log in first.");
        _isLoading = false;
        notifyListeners();
        return [];
      }

      // ✅ API call (endpoint starts with /api)
      final response = await ApiClient.getRequestWithAuth(
        '/api/get-grammar-tips',
        storedToken,
      );

      _isLoading = false;
      notifyListeners();

      // ✅ Expected JSON format:
      // { "status": true, "message": "Grammar Tips fetched successfully", "data": [] }
      if (response is Map<String, dynamic>) {
        if (response['status'] == true) {
          debugPrint("✅ Grammar Tips fetched successfully");
          return List<dynamic>.from(response['data'] ?? []);
        } else {
          debugPrint("⚠️ Failed: ${response['message']}");
          return [];
        }
      }

      debugPrint("⚠️ Unexpected grammar tips response: $response");
      return [];
    } catch (e) {
      debugPrint("❌ Error fetching grammar tips: $e");
      _isLoading = false;
      notifyListeners();
      return [];
    }
  }

  /// ⏰ Set Daily Reminder (Final Fixed)
  Future<bool> setDailyReminder(String reminderTime) async {
    _isLoading = true;
    notifyListeners();

    try {
      final prefs = await SharedPreferences.getInstance();
      final storedToken = prefs.getString('auth_token');
      debugPrint("🔐 Loaded token: $storedToken");

      if (storedToken == null || storedToken.isEmpty) {
        debugPrint("❌ No auth token found. Please log in again.");
        _isLoading = false;
        notifyListeners();
        return false;
      }

      debugPrint(
          '🌐 Sending reminder to: https://inangreji.in/api/set-reminder');
      debugPrint('🕒 Reminder time: $reminderTime');

      final response = await ApiClient.postRequestWithAuth(
        '/api/set-reminder',
        {'reminder_time': reminderTime},
        storedToken.trim(),
      );

      debugPrint(
          "🔔 Reminder API Response (Full JSON): ${jsonEncode(response)}");

      _isLoading = false;
      notifyListeners();

      final message = response['message']?.toString().toLowerCase() ?? '';
      final success = response['status'] == true ||
          response['success'] == true ||
          response['status'] == 'true' ||
          response['success'] == 'true' ||
          message.contains('success');

      if (success) {
        debugPrint("✅ Reminder set successfully: $message");
        return true;
      } else {
        debugPrint("⚠️ Failed to set reminder: $message");
        return false;
      }
    } catch (e) {
      _isLoading = false;
      notifyListeners();
      debugPrint("❌ Error setting reminder: $e");
      return false;
    }
  }

  /// ⏰ Get Daily Reminder (Final Fixed)
  Future<Map<String, dynamic>?> getReminder() async {
    _isLoading = true;
    notifyListeners();

    try {
      final prefs = await SharedPreferences.getInstance();
      final storedToken = prefs.getString('auth_token');

      if (storedToken == null || storedToken.isEmpty) {
        debugPrint("❌ No token found. Please log in first.");
        _isLoading = false;
        notifyListeners();
        return null;
      }

      // ✅ No need to prefix /api (ApiClient already handles it)
      final response = await ApiClient.getRequestWithAuth(
        '/api/get-reminder', // keep /api here (since getRequestWithAuth expects full)
        storedToken,
      );

      debugPrint("🕒 Reminder GET Response: $response");

      _isLoading = false;
      notifyListeners();

      if (response is Map<String, dynamic> && (response['status'] ?? false)) {
        debugPrint("✅ Reminder fetched successfully");
        return response['data'];
      } else {
        debugPrint("⚠️ Failed to fetch reminder data: $response");
        return null;
      }
    } catch (e) {
      _isLoading = false;
      notifyListeners();
      debugPrint("❌ Error fetching reminder: $e");
      return null;
    }
  }
}
