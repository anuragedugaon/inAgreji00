class OpenAIConfig {
  static const String apiKey =
      "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";
}
