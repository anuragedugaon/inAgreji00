import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';

// 🧠 App Provider
import 'package:inangreji_flutter/provider/app_provider.dart';

// 🧭 Routes
import 'package:inangreji_flutter/routes/app_routes.dart';

import 'provider/payment_method/paymentProvider.dart' show PaymentProvider;
import 'services/video_manager.dart';

// void main() async {
//   WidgetsFlutterBinding.ensureInitialized();

//   // ✅ Create and preload the app provider (loads saved language)
//   final appProvider = AppProvider();
//   await appProvider.loadLocale();

//   runApp(
//     ChangeNotifierProvider.value(
//       value: appProvider,
//       child: const InAngrejiApp(),
//     ),
//   );
// }

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final appProvider = AppProvider();
  await appProvider.loadLocale();
 VideoManager.initialize();
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider<AppProvider>.value(value: appProvider),
        ChangeNotifierProvider<PaymentProvider>(create: (_) => PaymentProvider()),
      ],
      child: const InAngrejiApp(),
    ),
  );
}



class InAngrejiApp extends StatelessWidget {
  const InAngrejiApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<AppProvider>(context);

    return MaterialApp(
      title: 'InAngreji',
      debugShowCheckedModeBanner: false,

      // 🌍 Language setup
      locale: provider.locale,
      supportedLocales: const [
        Locale('en'),
        Locale('hi'),
        Locale('bn'),
      ],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      localeResolutionCallback:
          (Locale? deviceLocale, Iterable<Locale> supportedLocales) {
        if (deviceLocale != null) {
          for (final locale in supportedLocales) {
            if (locale.languageCode == deviceLocale.languageCode) {
              return locale;
            }
          }
        }
        return supportedLocales.first; // default to English
      },

      // 🎨 Theme
      theme: ThemeData(
        scaffoldBackgroundColor: Colors.black,
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF00BFFF),
          secondary: Color(0xFF00BFFF),
        ),
        textTheme: const TextTheme(
          bodyLarge: TextStyle(color: Colors.white),
          bodyMedium: TextStyle(color: Colors.white70),
        ),
      ),

      // 🧭 Routes (load all from app_routes.dart)
      routes: AppRoutes.routes,

      // 🏁 Initial route
      initialRoute: AppRoutes.splash1,

      // 🌀 Optional: add smooth fade transitions for all routes
      onGenerateRoute: (settings) {
        final builder = AppRoutes.routes[settings.name];
        if (builder != null) {
          return PageRouteBuilder(
            pageBuilder: (_, __, ___) => builder(_),
            transitionsBuilder:
                (context, animation, secondaryAnimation, child) {
              final fade =
                  CurvedAnimation(parent: animation, curve: Curves.easeInOut);
              return FadeTransition(opacity: fade, child: child);
            },
            transitionDuration: const Duration(milliseconds: 500),
            settings: settings,
          );
        }
        // Fallback if route not found
        return MaterialPageRoute(
          builder: (_) => AppRoutes.routes[AppRoutes.splash1]!(_),
        );
      },
    );
  }
}
